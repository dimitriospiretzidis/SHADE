function varargout = select_portion(varargin)
% SELECT_PORTION MATLAB code for select_portion.fig
%      SELECT_PORTION, by itself, creates a new SELECT_PORTION or raises the existing
%      singleton*.
%
%      H = SELECT_PORTION returns the handle to a new SELECT_PORTION or the handle to
%      the existing singleton*.
%
%      SELECT_PORTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECT_PORTION.M with the given input arguments.
%
%      SELECT_PORTION('Property','Value',...) creates a new SELECT_PORTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before select_portion_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to select_portion_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help select_portion

% Last Modified by GUIDE v2.5 29-Oct-2017 19:13:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @select_portion_OpeningFcn, ...
                   'gui_OutputFcn',  @select_portion_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before select_portion is made visible.
function select_portion_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to select_portion (see VARARGIN)

% Choose default command line output for select_portion
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes select_portion wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%Set global variables
global data_por_cs por_choice por_start_degree por_end_degree por_start_order por_end_order
global por_start_degree_2 por_end_degree_2 por_r por_par_table

%Move GUI at the center of screen
movegui(gcf,'center')

%Initialize variables and GUI controls
set(handles.edit1,'Enable','off')
set(handles.edit2,'Enable','off')
set(handles.edit3,'Enable','off')
set(handles.edit4,'Enable','off')
set(handles.edit5,'Enable','off')
set(handles.edit6,'Enable','off')
set(handles.edit7,'Enable','off')

set(handles.togglebutton1,'Enable','off')

set(handles.uitable1,'Enable','off')

set(handles.pushbutton1,'Enable','off')

if isempty(data_por_cs) == 0
    
    if strcmp(por_choice,'1') == 1 || strcmp(por_choice,'12') == 1 || strcmp(por_choice,'13') == 1 || strcmp(por_choice,'123') == 1
        
        set(handles.radiobutton1,'Value',1)
        
        set(handles.edit1,'Enable','on')
        set(handles.edit2,'Enable','on')
        set(handles.edit3,'Enable','on')
        set(handles.edit4,'Enable','on')
        
        set(handles.edit1,'String',num2str(por_start_degree))
        set(handles.edit2,'String',num2str(por_end_degree))
        set(handles.edit3,'String',num2str(por_start_order))
        set(handles.edit4,'String',num2str(por_end_order))
        
        edit1_Callback(hObject, eventdata, handles)
        
    end
    
    if strcmp(por_choice,'2') == 1 || strcmp(por_choice,'12') == 1 || strcmp(por_choice,'23') == 1 || strcmp(por_choice,'123') == 1
        
        set(handles.radiobutton2,'Value',1)
        
        set(handles.edit5,'Enable','on')
        set(handles.edit6,'Enable','on')
        set(handles.edit7,'Enable','on')
        
        set(handles.togglebutton1,'Enable','off')
        
        set(handles.edit5,'String',num2str(por_start_degree_2))
        set(handles.edit6,'String',num2str(por_end_degree_2))
        set(handles.edit7,'String',num2str(por_r))
        
        set(handles.togglebutton1,'Enable','on')
        
        edit5_Callback(hObject, eventdata, handles)
        
    end
    
    if strcmp(por_choice,'3') == 1 || strcmp(por_choice,'13') == 1 || strcmp(por_choice,'23') == 1 || strcmp(por_choice,'123') == 1
        
        set(handles.radiobutton3,'Value',1)
        
        set(handles.uitable1,'Data',por_par_table)
        
        set(handles.uitable1,'Enable','on')
        
        set(handles.pushbutton1,'Enable','on')
        
    end
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
end


% --- Outputs from this function are returned to the command line.
function varargout = select_portion_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

%Initialize variables and GUI controls
if get(handles.radiobutton1,'Value') == 1
    
    set(handles.edit1,'Enable','on')
    set(handles.edit2,'Enable','on')
    set(handles.edit3,'Enable','on')
    set(handles.edit4,'Enable','on')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
elseif get(handles.radiobutton1,'Value') == 0
    
    set(handles.edit1,'Enable','off')
    set(handles.edit2,'Enable','off')
    set(handles.edit3,'Enable','off')
    set(handles.edit4,'Enable','off')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

if get(handles.radiobutton2,'Value') == 1
    
    set(handles.edit5,'Enable','on')
    set(handles.edit6,'Enable','on')
    set(handles.edit7,'Enable','on')
    
    set(handles.togglebutton1,'Enable','on')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
elseif get(handles.radiobutton2,'Value') == 0
    
    set(handles.edit5,'Enable','off')
    set(handles.edit6,'Enable','off')
    set(handles.edit7,'Enable','off')
    
    set(handles.togglebutton1,'Value',0)
    set(handles.togglebutton1,'Enable','off')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3

if get(handles.radiobutton3,'Value') == 1
    
    set(handles.uitable1,'Enable','on')
    set(handles.pushbutton1,'Enable','on')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
elseif get(handles.radiobutton3,'Value') == 0
    
    set(handles.uitable1,'Enable','off')
    set(handles.pushbutton1,'Enable','off')
    
    %Update portion
    update_portion(hObject, eventdata, handles)
    
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double

update_portion(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1

if get(handles.togglebutton1,'Value') == 1
    
    axes(handles.axes1)
    reset(handles.axes1)
    colorbar off
    cla
    text('String',{'$n = n_{0} + \beta m^{r}$','with','$n_{0} = n_{start}$','$\beta = \frac{n_{end} - n_{start}}{{n_{end}^{r}}}$'},'Interpreter','LaTeX','FontSize',35,'HorizontalAlignment','Center','Position',[0.5 0.5])
    axis off
    
elseif get(handles.togglebutton1,'Value') == 0
    
    update_portion(hObject, eventdata, handles)
    
end


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

update_portion(hObject, eventdata, handles)

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Create clear table
por_par_clear{4,2} = [];

%Clear table
set(handles.uitable1,'Data',por_par_clear)
uitable1_CellEditCallback(hObject, eventdata, handles)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global por_success data_por_cs_l_c data_por_sc_l_c por_choice_l_c
global por_start_degree_l_c por_end_degree_l_c por_start_order_l_c
global por_end_order_l_c por_start_degree_2_l_c por_end_degree_2_l_c
global por_r_l_c por_par_table_l_c por_choice por_start_degree
global por_end_degree por_start_order por_end_order por_start_degree_2
global por_end_degree_2 por_r por_par_table data_por_cs data_por_sc

%Update portion matrix
update_portion(hObject, eventdata, handles);

if por_success ~= 0
    
    data_por_cs         = data_por_cs_l_c;
    data_por_sc         = data_por_sc_l_c;
    por_choice          = por_choice_l_c;
    por_start_degree    = por_start_degree_l_c;
    por_end_degree      = por_end_degree_l_c;
    por_start_order     = por_start_order_l_c;
    por_end_order       = por_end_order_l_c;
    por_start_degree_2  = por_start_degree_2_l_c;
    por_end_degree_2    = por_end_degree_2_l_c;
    por_r               = por_r_l_c;
    por_par_table       = por_par_table_l_c;
    
    %Change SHADE GUI controls
    shade_h             = findobj('Tag','SHADE');
    shade_gui           = guidata(shade_h);
    
    set(shade_gui.pushbutton14,'Enable','on')
    set(shade_gui.menu_portion,'Checked','on')
    
    %Close GUI
    close(select_portion)
    
else
    errordlg('Parameters are not valid or not complete.','Error')
end


function update_portion(hObject, eventdata, handles)
%Set global variables
global data_cs vis_format data_por_cs_l_c data_por_sc_l_c por_success 
global por_choice_l_c por_start_degree_l_c por_end_degree_l_c
global por_start_order_l_c por_end_order_l_c por_start_degree_2_l_c
global por_end_degree_2_l_c por_r_l_c por_par_table_l_c

try
    
    por_choice_l_c = [];
    
    %Check for the first portion matrix
    if get(handles.radiobutton1,'Value') == 1
        
        %Get portion parameters
        por_start_degree_temp = str2double(get(handles.edit1,'String'));
        por_end_degree_temp   = str2double(get(handles.edit2,'String'));
        por_start_order_temp  = str2double(get(handles.edit3,'String'));
        por_end_order_temp    = str2double(get(handles.edit4,'String'));
        
        %Calculate portion matrix
        data_por_cs_1_temp    = f_dec_por_1(data_cs,por_start_degree_temp,por_end_degree_temp,....
                                            por_start_order_temp,por_end_order_temp);
        
        %If portion matrix is correct, save all variables
        por_choice_l_c        = '1';
        por_start_degree_l_c  = por_start_degree_temp;
        por_end_degree_l_c    = por_end_degree_temp;
        por_start_order_l_c   = por_start_order_temp;
        por_end_order_l_c     = por_end_order_temp;
        data_por_cs_1_l_c     = data_por_cs_1_temp;
        
    end
    
    %Check for the second portion matrix
    if get(handles.radiobutton2,'Value') == 1
        
        %Get portion parameters
        por_start_degree_2_temp = str2double(get(handles.edit5,'String'));
        por_end_degree_2_temp   = str2double(get(handles.edit6,'String'));
        por_r_temp              = str2double(get(handles.edit7,'String'));
        
        %Calculate portion matrix
        warning('off','all')
        
        data_por_cs_2_temp      = f_dec_por_2(data_cs,por_r_temp,por_start_degree_2_temp,0,...
                                              por_end_degree_2_temp,por_end_degree_2_temp);
        
        warning('on','all')
        
        %If portion matrix is correct, save all variables
        por_choice_l_c          = [por_choice_l_c '2'];
        por_start_degree_2_l_c  = por_start_degree_2_temp;
        por_end_degree_2_l_c    = por_end_degree_2_temp;
        por_r_l_c               = por_r_temp;
        data_por_cs_2_l_c       = data_por_cs_2_temp;
        
    end
    
    %Check for the third portion matrix
    if get(handles.radiobutton3,'Value') == 1
        
        %Get data from table
        por_par_table_temp      = get(handles.uitable1,'Data');
        
        %Add a new row to table
        if isempty(cell2mat(por_par_table_temp(end,:))) == 0
            
            por_par_table_temp{end + 1,1} = [];
            
            set(handles.uitable1,'Data',por_par_table_temp)
            
        end
        
        %Calculate portion matrix
        C_orders                = cell2mat(por_par_table_temp(:,1));
        S_orders                = cell2mat(por_par_table_temp(:,2));
        [data_por_cs_3_temp,...
         C_c,S_c]               = f_dec_por_3(data_cs,C_orders,S_orders);
        
        C_size                  = size(C_c,1);
        S_size                  = size(S_c,1);
        
        %If portion matrix is correct, save all variables
        por_choice_l_c          = [por_choice_l_c '3'];
        
        por_par_table_l_c = {[]};
        
        por_par_table_l_c(1:size(C_c,1),1) = num2cell(C_c);
        por_par_table_l_c(1:size(S_c,1),2) = num2cell(S_c);
        data_por_cs_3_l_c       = data_por_cs_3_temp;
        
    end
    
    %Check if any of the portion matrices are selected
    if get(handles.radiobutton1,'Value') == 0 && get(handles.radiobutton2,'Value') == 0 && get(handles.radiobutton3,'Value') == 0
        
        error('No selection has been made')
        
    end
    
    %Initialize portion matrix
    data_por_cs_l_c             = ones(size(data_cs,1));
    
    %Calculate cascaded portion matrix
    if get(handles.radiobutton1,'Value') == 1
        
        data_por_cs_l_c         = +(data_por_cs_l_c & data_por_cs_1_l_c);
        
    end
    
    if get(handles.radiobutton2,'Value') == 1
        
        data_por_cs_l_c         = +(data_por_cs_l_c & data_por_cs_2_l_c);
        
    end
    
    if get(handles.radiobutton3,'Value') == 1
        
        data_por_cs_l_c         = +(data_por_cs_l_c & data_por_cs_3_l_c);
        
    end
    
    data_por_sc_l_c             = f_cs2sc(data_por_cs_l_c);
    
    %Plot the window matrix
    if get(handles.togglebutton1,'Value') == 0
        
        axes(handles.axes1)
        
        if vis_format == 1
            
            f_plot_cs(data_por_cs_l_c,'linear','yes')
            
        elseif vis_format == 2
            
            f_plot_sc(data_por_sc_l_c,'linear','yes')
            
        end
        
    end
    
    por_success                 = 1;
    
catch
    
    if get(handles.togglebutton1,'Value') ~= 1
        
        %Clear and reset axes
        axes(handles.axes1)
        reset(handles.axes1)
        colorbar off
        cla
        axis off
        
    end
    
    por_success                 = 0;
    
end
