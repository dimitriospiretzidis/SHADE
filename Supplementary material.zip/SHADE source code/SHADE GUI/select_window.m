function varargout = select_window(varargin)
% SELECT_WINDOW MATLAB code for select_window.fig
%      SELECT_WINDOW, by itself, creates a new SELECT_WINDOW or raises the existing
%      singleton*.
%
%      H = SELECT_WINDOW returns the handle to a new SELECT_WINDOW or the handle to
%      the existing singleton*.
%
%      SELECT_WINDOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECT_WINDOW.M with the given input arguments.
%
%      SELECT_WINDOW('Property','Value',...) creates a new SELECT_WINDOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before select_window_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to select_window_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help select_window

% Last Modified by GUIDE v2.5 12-Dec-2017 18:31:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @select_window_OpeningFcn, ...
                   'gui_OutputFcn',  @select_window_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before select_window is made visible.
function select_window_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to select_window (see VARARGIN)

% Choose default command line output for select_window
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes select_window wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%Set global variables
global data_win_cs win_choice win_A win_K win_gamma win_pe win_par_table data_win_por

%Move GUI at the center of screen
movegui(gcf,'center')

if isempty(data_win_cs) == 1
    
    %Initialize variables and GUI controls
    set(handles.edit1,'Enable','off')
    set(handles.edit2,'Enable','off')
    set(handles.edit3,'Enable','off')
    set(handles.edit4,'Enable','off')
    set(handles.edit5,'Enable','off')
    set(handles.edit6,'Enable','off')
    
    set(handles.togglebutton1,'Enable','off')
    set(handles.togglebutton2,'Enable','off')
    
    set(handles.edit7,'Enable','off')
    set(handles.checkbox1,'Enable','off')
    
    set(handles.uitable1,'Enable','off')
    set(handles.pushbutton2,'Enable','off')
    
elseif isempty(data_win_cs) == 0
    
    if win_choice == 1
        
        set(handles.radiobutton1,'Value',1)
        
        radiobutton1_Callback(hObject, eventdata, handles)
        
        set(handles.edit1,'String',num2str(win_A))
        set(handles.edit2,'String',num2str(win_K))
        
        edit1_Callback(hObject, eventdata, handles)
        
    elseif win_choice == 2
        
        set(handles.radiobutton2,'Value',1)
        
        radiobutton2_Callback(hObject, eventdata, handles)
        
        set(handles.edit3,'String',num2str(win_A))
        set(handles.edit4,'String',num2str(win_K))
        set(handles.edit5,'String',num2str(win_gamma))
        set(handles.edit6,'String',num2str(win_pe))
        
        edit3_Callback(hObject, eventdata, handles)
        
    elseif win_choice == 3
        
        set(handles.radiobutton3,'Value',1)
        set(handles.checkbox1,'Value',data_win_por)
        
        radiobutton3_Callback(hObject, eventdata, handles)
        
    elseif win_choice == 4
        
        set(handles.radiobutton4,'Value',1)
        
        radiobutton4_Callback(hObject, eventdata, handles)
        
        set(handles.uitable1,'Data',win_par_table)
        
        set(handles.uitable1,'Enable','on')
        
        set(handles.pushbutton2,'Enable','on')
        
        uitable1_CellEditCallback(hObject, eventdata, handles)
        
    end
    
end


% --- Outputs from this function are returned to the command line.
function varargout = select_window_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global win_success data_win_cs_l_c data_win_sc_l_c win_choice_l_c win_A_l_c win_K_l_c win_gamma_l_c win_pe_l_c win_par_table_l_c data_win_por_l_c
global data_win_cs data_win_sc win_choice win_A win_K win_gamma win_pe win_par_table data_win_por

%Update window length
update_window(hObject, eventdata, handles);

if win_success ~= 0
    
    data_win_cs         = data_win_cs_l_c;
    data_win_sc         = data_win_sc_l_c;
    win_choice          = win_choice_l_c;
    win_A               = win_A_l_c;
    win_K               = win_K_l_c;
    win_gamma           = win_gamma_l_c;
    win_pe              = win_pe_l_c;
    win_par_table       = win_par_table_l_c;
    data_win_por        = data_win_por_l_c;
    
    %Change SHADE GUI controls
    shade_h             = findobj('Tag','SHADE');
    shade_gui           = guidata(shade_h);
    
    set(shade_gui.pushbutton12,'Enable','on')
    set(shade_gui.menu_window,'Checked','on')
    
    %Close GUI
    close(select_window)
    
else
    errordlg('Parameters are not valid or not complete.','Error')
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Create clear table
win_par_clear{4,2} = [];

%Clear table
set(handles.uitable1,'Data',win_par_clear)
uitable1_CellEditCallback(hObject, eventdata, handles)


% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1

if get(handles.togglebutton1,'Value') == 1
    
    set(handles.togglebutton2,'Value',0)
    
    axes(handles.axes1)
    reset(handles.axes1)
    colorbar off
    cla
    text('String',{'$w = max(x + 1,5)$','with','$x = Ae^{-\frac{m}{K}}$'},'Interpreter','LaTeX','FontSize',35,'HorizontalAlignment','Center','Position',[0.5 0.5])
    axis off
    
elseif get(handles.togglebutton1,'Value') == 0
    
    %Update window length
    update_window(hObject, eventdata, handles)
    
end


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2

if get(handles.togglebutton2,'Value') == 1
    
    set(handles.togglebutton1,'Value',0)
    
    axes(handles.axes1)
    reset(handles.axes1)
    colorbar off
    cla
    text('String',{'$w = max(x + 1,5)$','with','$x = Ae^{-\frac{[(1 - \gamma)m^{p} + \gamma l^{p}]^{\frac{1}{p}}}{K}}$'},'Interpreter','LaTeX','FontSize',35,'HorizontalAlignment','Center','Position',[0.5 0.5])
    axis off
    
elseif get(handles.togglebutton2,'Value') == 0
    
    %Update window length
    update_window(hObject, eventdata, handles)
    
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

%Initialize variables and GUI controls
set(handles.radiobutton1,'Value',1)
set(handles.radiobutton2,'Value',0)
set(handles.radiobutton3,'Value',0)
set(handles.radiobutton4,'Value',0)

set(handles.edit1,'Enable','on')
set(handles.edit2,'Enable','on')
set(handles.edit3,'Enable','off')
set(handles.edit4,'Enable','off')
set(handles.edit5,'Enable','off')
set(handles.edit6,'Enable','off')

set(handles.togglebutton1,'Enable','on')

if get(handles.togglebutton2,'Value') == 1
    
    set(handles.togglebutton2,'Value',0)
    togglebutton2_Callback(hObject, eventdata, handles)
    
end

set(handles.togglebutton2,'Enable','off')

set(handles.edit7,'Enable','off')
set(handles.checkbox1,'Enable','off')

set(handles.uitable1,'Enable','off')
set(handles.pushbutton2,'Enable','off')

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

%Initialize variables and GUI controls
set(handles.radiobutton1,'Value',0)
set(handles.radiobutton2,'Value',1)
set(handles.radiobutton3,'Value',0)
set(handles.radiobutton4,'Value',0)

set(handles.edit1,'Enable','off')
set(handles.edit2,'Enable','off')
set(handles.edit3,'Enable','on')
set(handles.edit4,'Enable','on')
set(handles.edit5,'Enable','on')
set(handles.edit6,'Enable','on')

if get(handles.togglebutton1,'Value') == 1
    
    set(handles.togglebutton1,'Value',0)
    togglebutton1_Callback(hObject, eventdata, handles)
    
end

set(handles.togglebutton1,'Enable','off')
set(handles.togglebutton2,'Enable','on')

set(handles.edit7,'Enable','off')
set(handles.checkbox1,'Enable','off')

set(handles.uitable1,'Enable','off')
set(handles.pushbutton2,'Enable','off')

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3

%Initialize variables and GUI controls
set(handles.radiobutton1,'Value',0)
set(handles.radiobutton2,'Value',0)
set(handles.radiobutton3,'Value',1)
set(handles.radiobutton4,'Value',0)

set(handles.edit1,'Enable','off')
set(handles.edit2,'Enable','off')
set(handles.edit3,'Enable','off')
set(handles.edit4,'Enable','off')
set(handles.edit5,'Enable','off')
set(handles.edit6,'Enable','off')

if get(handles.togglebutton1,'Value') == 1
    
    set(handles.togglebutton1,'Value',0)
    togglebutton1_Callback(hObject, eventdata, handles)
    
end

if get(handles.togglebutton2,'Value') == 1
    
    set(handles.togglebutton2,'Value',0)
    togglebutton2_Callback(hObject, eventdata, handles)
    
end

set(handles.togglebutton1,'Enable','off')
set(handles.togglebutton2,'Enable','off')

set(handles.edit7,'Enable','on')
set(handles.checkbox1,'Enable','on')

set(handles.uitable1,'Enable','off')
set(handles.pushbutton2,'Enable','off')

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4

%Initialize variables and GUI controls
set(handles.radiobutton1,'Value',0)
set(handles.radiobutton2,'Value',0)
set(handles.radiobutton3,'Value',0)
set(handles.radiobutton4,'Value',1)

set(handles.edit1,'Enable','off')
set(handles.edit2,'Enable','off')
set(handles.edit3,'Enable','off')
set(handles.edit4,'Enable','off')
set(handles.edit5,'Enable','off')
set(handles.edit6,'Enable','off')

if get(handles.togglebutton1,'Value') == 1
    
    set(handles.togglebutton1,'Value',0)
    togglebutton1_Callback(hObject, eventdata, handles)
    
end

if get(handles.togglebutton2,'Value') == 1
    
    set(handles.togglebutton2,'Value',0)
    togglebutton2_Callback(hObject, eventdata, handles)
    
end

set(handles.togglebutton1,'Enable','off')
set(handles.togglebutton2,'Enable','off')

set(handles.edit7,'Enable','off')
set(handles.checkbox1,'Enable','off')

set(handles.uitable1,'Enable','on')
set(handles.pushbutton2,'Enable','on')

%Update window length
update_window(hObject, eventdata, handles)


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1

%Set global variables
global data_por_cs

if isempty(data_por_cs) == 1
    
    errordlg('Portion matrix is not selected.','Error')
    
    set(handles.checkbox1,'Value',0)
    
else
    
    update_window(hObject, eventdata, handles)
    
end


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

update_window(hObject, eventdata, handles)


function update_window(hObject, eventdata, handles)

%Set global variables
global data_cs vis_format data_win_cs_l_c data_win_sc_l_c win_success
global win_choice_l_c win_A_l_c win_K_l_c win_gamma_l_c win_pe_l_c win_par_table_l_c
global data_win_por_l_c data_por_cs

try
    
    if get(handles.radiobutton1,'Value') == 1
        
        %Get window length parameters
        win_A_temp           = str2double(get(handles.edit1,'String'));
        win_K_temp           = str2double(get(handles.edit2,'String'));
        
        %Calculate window length
        data_win_cs_temp     = f_dec_win_1(data_cs,win_A_temp,win_K_temp);
        
        %If window length is correct, save all variables
        win_choice_l_c       = 1;
        win_A_l_c            = win_A_temp;
        win_K_l_c            = win_K_temp;
        data_win_cs_l_c      = data_win_cs_temp;
        data_win_sc_l_c      = f_cs2sc(data_win_cs_l_c);
        
        %Plot the window length matrix
        if get(handles.togglebutton1,'Value') == 0
            
            axes(handles.axes1)
            
            if vis_format == 1
                
                f_plot_cs(data_win_cs_l_c,'linear','yes')
                
            elseif vis_format == 2
                
                f_plot_sc(data_win_sc_l_c,'linear','yes')
                
            end
            
        end
        
        win_success          = 1;
        
    elseif get(handles.radiobutton2,'Value') == 1
        
        %Get window length parameters
        win_A_temp           = str2double(get(handles.edit3,'String'));
        win_K_temp           = str2double(get(handles.edit4,'String'));
        win_gamma_temp       = str2double(get(handles.edit5,'String'));
        win_pe_temp          = str2double(get(handles.edit6,'String'));
        
        %Calculate window length
        data_win_cs_temp     = f_dec_win_2(data_cs,win_A_temp,win_K_temp,win_gamma_temp,win_pe_temp);
        
        %If window length is correct, save all variables
        win_choice_l_c       = 2;
        win_A_l_c            = win_A_temp;
        win_K_l_c            = win_K_temp;
        win_gamma_l_c        = win_gamma_temp;
        win_pe_l_c           = win_pe_temp;
        data_win_cs_l_c      = data_win_cs_temp;
        data_win_sc_l_c      = f_cs2sc(data_win_cs_l_c);
        
        %Plot the window length matrix
        if get(handles.togglebutton2,'Value') == 0
            
            axes(handles.axes1)
            
            if vis_format == 1
                
                f_plot_cs(data_win_cs_l_c,'linear','yes')
                
            elseif vis_format == 2
                
                f_plot_sc(data_win_sc_l_c,'linear','yes')
                
            end
            
        end
        
        win_success          = 1;
        
    elseif get(handles.radiobutton3,'Value') == 1
        
        %Calculate window length
        if get(handles.checkbox1,'Value') == 0
            
            data_win_cs_temp     = f_dec_win_3(data_cs);
            
        elseif get(handles.checkbox1,'Value') == 1
            
            data_win_cs_temp     = f_dec_win_3(data_cs,data_por_cs);
            
        end
        
        %If window length is correct, save all variables
        win_choice_l_c       = 3;
        data_win_cs_l_c      = data_win_cs_temp;
        data_win_sc_l_c      = f_cs2sc(data_win_cs_l_c);
        data_win_por_l_c     = get(handles.checkbox1,'Value');
        
        %Plot the window length matrix
        axes(handles.axes1)
        
        if vis_format == 1
            
            f_plot_cs(data_win_cs_l_c,'linear','yes')
            
        elseif vis_format == 2
            
            f_plot_sc(data_win_sc_l_c,'linear','yes')
            
        end
        
        win_success          = 1;
        
    elseif get(handles.radiobutton4,'Value') == 1
        
        %Get data from table
        win_par_table_temp      = get(handles.uitable1,'Data');
        
        %Add a new row to table
        if isempty(cell2mat(win_par_table_temp(end,:))) == 0
            
            win_par_table_temp{end + 1,1} = [];
            
            set(handles.uitable1,'Data',win_par_table_temp)
            
        end
        
        %Calculate portion matrix
        win_par                      = cell2mat(win_par_table_temp);
        [data_win_cs_temp,win_par_c] = f_dec_win_4(data_cs,win_par(:,1),win_par(:,2));
                
        %If window length is correct, save all variables
        win_choice_l_c          = 4;
        
        win_par_table_l_c     = num2cell(win_par_c);
        data_win_cs_l_c       = data_win_cs_temp;
        data_win_sc_l_c       = f_cs2sc(data_win_cs_l_c);
        
        %Plot the window length matrix
        if get(handles.togglebutton2,'Value') == 0
            
            axes(handles.axes1)
            
            if vis_format == 1
                
                f_plot_cs(data_win_cs_l_c,'linear','yes')
                
            elseif vis_format == 2
                
                f_plot_sc(data_win_sc_l_c,'linear','yes')
                
            end
            
        end
        
        win_success          = 1;
        
    else
        
        win_success          = 0;
        
    end
    
catch
    
    if get(handles.togglebutton1,'Value') ~= 1 && get(handles.togglebutton2,'Value') ~= 1
        
        %Clear and reset axes
        axes(handles.axes1)
        reset(handles.axes1)
        colorbar off
        cla
        axis off
        
    end
    
    win_success              = 0;
    
end
