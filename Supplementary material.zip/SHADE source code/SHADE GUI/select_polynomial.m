function varargout = select_polynomial(varargin)
% SELECT_POLYNOMIAL MATLAB code for select_polynomial.fig
%      SELECT_POLYNOMIAL, by itself, creates a new SELECT_POLYNOMIAL or raises the existing
%      singleton*.
%
%      H = SELECT_POLYNOMIAL returns the handle to a new SELECT_POLYNOMIAL or the handle to
%      the existing singleton*.
%
%      SELECT_POLYNOMIAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECT_POLYNOMIAL.M with the given input arguments.
%
%      SELECT_POLYNOMIAL('Property','Value',...) creates a new SELECT_POLYNOMIAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before select_polynomial_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to select_polynomial_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help select_polynomial

% Last Modified by GUIDE v2.5 20-Oct-2017 15:47:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @select_polynomial_OpeningFcn, ...
                   'gui_OutputFcn',  @select_polynomial_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before select_polynomial is made visible.
function select_polynomial_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to select_polynomial (see VARARGIN)

% Choose default command line output for select_polynomial
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes select_polynomial wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%Set global variables
global pol_par_table

%Move GUI at the center of screen
movegui(gcf,'center')

if isempty(pol_par_table) == 0
    
    set(handles.uitable1,'Data',pol_par_table)
    uitable1_CellEditCallback(hObject, eventdata, handles)
    
end


% --- Outputs from this function are returned to the command line.
function varargout = select_polynomial_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global pol_success pol_par_table_l_c data_pol_cs_l_c data_pol_sc_l_c
global pol_par_table data_pol_cs data_pol_sc

if pol_success ~= 0
    
    pol_par_table       = pol_par_table_l_c;
    data_pol_cs         = data_pol_cs_l_c;
    data_pol_sc         = data_pol_sc_l_c;
    
    %Change SHADE GUI controls
    shade_h             = findobj('Tag','SHADE');
    shade_gui           = guidata(shade_h);
    
    set(shade_gui.pushbutton10,'Enable','on')
    set(shade_gui.menu_polynomial,'Checked','on')
    
    %Close GUI
    close(select_polynomial)
    
else
    errordlg('Parameters are not valid or not complete.','Error')
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Create clear table
pol_par_clear{4,2} = [];

%Clear table
set(handles.uitable1,'Data',pol_par_clear)
uitable1_CellEditCallback(hObject, eventdata, handles)


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global pol_par_table_l_c data_cs vis_format data_pol_cs_l_c data_pol_sc_l_c pol_success

try
    
    %Get data from table
    pol_par_table_temp                = get(handles.uitable1,'Data');
    
    %Add a new row to table
    if isempty(cell2mat(pol_par_table_temp(end,:))) == 0
        
        pol_par_table_temp{end + 1,1} = [];
        
        set(handles.uitable1,'Data',pol_par_table_temp)
        
    end
    
    %Create the polynomial degree matrix
    pol_par                      = cell2mat(pol_par_table_temp);
    [data_pol_temp,pol_par_c]    = f_dec_pol(data_cs,pol_par(:,1),pol_par(:,2));
    
    pol_par_table_l_c            = num2cell(pol_par_c);
    data_pol_cs_l_c              = data_pol_temp;
    data_pol_sc_l_c              = f_cs2sc(data_pol_cs_l_c);
    
    %Plot the polynomial degree matrix
    axes(handles.axes1)
    
    if vis_format == 1
        
        f_plot_cs(data_pol_cs_l_c,'linear','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_pol_sc_l_c,'linear','yes')
        
    end
    
    pol_success                  = 1;
    
catch
    
    pol_success                  = 0;
    
end
