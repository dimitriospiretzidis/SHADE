function varargout = SHADE(varargin)
% SHADE MATLAB code for SHADE.fig
%      SHADE, by itself, creates a new SHADE or raises the existing
%      singleton*.
%
%      H = SHADE returns the handle to a new SHADE or the handle to
%      the existing singleton*.
%
%      SHADE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SHADE.M with the given input arguments.
%
%      SHADE('Property','Value',...) creates a new SHADE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SHADE_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SHADE_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SHADE

% Last Modified by GUIDE v2.5 11-Dec-2017 22:54:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SHADE_OpeningFcn, ...
                   'gui_OutputFcn',  @SHADE_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SHADE is made visible.
function SHADE_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SHADE (see VARARGIN)

% Choose default command line output for SHADE
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SHADE wait for user response (see UIRESUME)
% uiwait(handles.SHADE);

%Clear global variables
clearvars -global

%Set global variables
global data_format vis_format LON LAT data_por_flag
global coastline_lat coastline_lon

%Move GUI at the center of screen
movegui(gcf,'center')

%Add SHADE directory into MATLAB
SHADE_GUI_dir = which('SHADE.m');
SHADE_GUI_dir = SHADE_GUI_dir(1:end-7);
SHADE_dir     = SHADE_GUI_dir(1:end-10);

addpath(genpath(SHADE_dir))

%Load data
load('coastline.mat')

%Initialize grid for spherical harmonic synthesis
grid_step      = 1;
lon            = (-180 + grid_step/2:grid_step:180 - grid_step/2);
lat            = (90 - grid_step/2:-grid_step:-90+grid_step/2);
[LON,LAT]      = meshgrid(lon,lat);

%Initialize variables and GUI controls
data_format    = 1;
data_por_flag  = 0;
vis_format     = 1;

set(handles.menu_cs,'Checked','on')
set(handles.menu_por_flag_0,'Checked','on')
set(handles.pushbutton3,'Enable','off')
set(handles.pushbutton4,'Enable','off')
set(handles.pushbutton6,'Enable','off')
set(handles.pushbutton7,'Enable','off')
set(handles.pushbutton10,'Enable','off')
set(handles.pushbutton12,'Enable','off')
set(handles.pushbutton14,'Enable','off')

set(handles.text3,'String','')
set(handles.text5,'String','')

set(handles.edit1,'Enable','off')
set(handles.edit2,'Enable','off')

set(handles.edit1,'String','')
set(handles.edit2,'String','')

set(handles.radiobutton1,'Enable','off')
set(handles.radiobutton2,'Enable','off')

set(handles.radiobutton1,'Value',1)
set(handles.radiobutton2,'Value',0)

set(handles.menu_parameters,'Enable','off')
set(handles.menu_decorrelate,'Enable','off')
set(handles.menu_export,'Enable','off')

%Clear and reset axes
axes(handles.axes1)
reset(handles.axes1)
colorbar off
cla
axis off

axes(handles.axes2)
reset(handles.axes2)
colorbar off
cla
axis off

axes(handles.new_axes_1)
legend off
reset(handles.new_axes_1)
colorbar off
cla
axis off

axes(handles.new_axes_2)
legend off
reset(handles.new_axes_2)
colorbar off
cla
axis off

axes(handles.axes4)
reset(handles.axes4)
colorbar off
cla
axis off

axes(handles.axes5)
reset(handles.axes5)
colorbar off
cla
axis off

axes(handles.new_axes_3)
legend off
reset(handles.new_axes_3)
colorbar off
cla
axis off

axes(handles.new_axes_4)
legend off
reset(handles.new_axes_4)
colorbar off
cla
axis off


% --- Outputs from this function are returned to the command line.
function varargout = SHADE_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_cs data_sc data_pot vis_format l_c_month l_c_order
global LON LAT coastline_lat coastline_lon data_cs_dec data_sc_dec
global data_pot_dec axes_1_lim axes_2_lim

set(handles.pushbutton3,'Enable','off')

%Get the number of current solution
new_month  = l_c_month - 1;

set(handles.edit1,'String',num2str(new_month))
set(handles.pushbutton4,'Enable','on')

l_c_month  = new_month;

%Visualize the previous solution
axes(handles.axes1)

if vis_format == 1
    
    f_plot_cs(data_cs(:,:,new_month),'logarithmic','yes')
    
elseif vis_format == 2
    
    f_plot_sc(data_sc(:,:,new_month),'logarithmic','yes')
    
end

axes_1_lim = caxis;

axes(handles.axes2)

pcolor(LON,LAT,data_pot(:,:,new_month));
hold on
plot(coastline_lon,coastline_lat,'-k')
hold off
axis image
shading flat
colorbar('SouthOutside');
set(gca,'Layer','top')

axes_2_lim           = 0.1*caxis;

caxis(axes_2_lim)

f_plot_even_odd(data_cs(:,:,new_month),l_c_order,'no','yes',handles);

%Visualize the previous de-correlated solution
if min(min(isnan(data_cs_dec(:,:,new_month)))) == 0
    
    axes(handles.axes4)
    
    if vis_format == 1
        
        f_plot_cs(data_cs_dec(:,:,new_month),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc_dec(:,:,new_month),'logarithmic','yes')
        
    end
    
    caxis(axes_1_lim)
    
    axes(handles.axes5)
    
    pcolor(LON,LAT,data_pot_dec(:,:,new_month));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside');
    set(gca,'Layer','top')
    
    caxis(axes_2_lim)
    
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,new_month),l_c_order,'no','yes_dec',handles);
    
else
    
    %Clear and reset axes
    axes(handles.axes4)
    reset(handles.axes4)
    colorbar off
    cla
    axis off
    
    axes(handles.axes5)
    reset(handles.axes5)
    colorbar off
    cla
    axis off
    
    axes(handles.new_axes_3)
    legend off
    reset(handles.new_axes_3)
    colorbar off
    cla
    axis off
    
    
    axes(handles.new_axes_4)
    legend off
    reset(handles.new_axes_4)
    colorbar off
    cla
    axis off
    
    
end

if new_month ~= 1
    
    set(handles.pushbutton3,'Enable','on')
    
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_cs data_sc data_pot num_month l_c_month l_c_order vis_format
global LON LAT coastline_lat coastline_lon data_cs_dec data_sc_dec
global data_pot_dec axes_1_lim axes_2_lim

set(handles.pushbutton4,'Enable','off')

%Get the number of current solution
new_month  = l_c_month + 1;

set(handles.edit1,'String',num2str(new_month))
set(handles.pushbutton3,'Enable','on')

l_c_month  = new_month;

%Visualize the next solution
axes(handles.axes1)

if vis_format == 1
    
    f_plot_cs(data_cs(:,:,new_month),'logarithmic','yes')
    
elseif vis_format == 2
    
    f_plot_sc(data_sc(:,:,new_month),'logarithmic','yes')
    
end

axes_1_lim = caxis;

axes(handles.axes2)

pcolor(LON,LAT,data_pot(:,:,new_month));
hold on
plot(coastline_lon,coastline_lat,'-k')
hold off
axis image
shading flat
colorbar('SouthOutside');
set(gca,'Layer','top')

axes_2_lim           = 0.1*caxis;

caxis(axes_2_lim)

f_plot_even_odd(data_cs(:,:,new_month),l_c_order,'no','yes',handles);

%Visualize the next de-correlated solution
if min(min(isnan(data_cs_dec(:,:,new_month)))) == 0
    
    axes(handles.axes4)
    
    if vis_format == 1
        
        f_plot_cs(data_cs_dec(:,:,new_month),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc_dec(:,:,new_month),'logarithmic','yes')
        
    end
    
    caxis(axes_1_lim)
    
    axes(handles.axes5)
    
    pcolor(LON,LAT,data_pot_dec(:,:,new_month));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside');
    set(gca,'Layer','top')
    
    caxis(axes_2_lim)
    
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,new_month),l_c_order,'no','yes_dec',handles);
    
else
    
    %Clear and reset axes
    axes(handles.axes4)
    reset(handles.axes4)
    colorbar off
    cla
    axis off
    
    axes(handles.axes5)
    reset(handles.axes5)
    colorbar off
    cla
    axis off
    
    axes(handles.new_axes_3)
    legend off
    reset(handles.new_axes_3)
    colorbar off
    cla
    axis off
    
    
    axes(handles.new_axes_4)
    legend off
    reset(handles.new_axes_4)
    colorbar off
    cla
    axis off
    
    
end

if new_month ~= num_month
    
    set(handles.pushbutton4,'Enable','on')
    
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.pushbutton6,'Enable','off')

%Set global variables
global data_cs data_cs_dec l_c_order l_c_month

%Get the number of current order
new_order = l_c_order - 1;

set(handles.edit2,'String',num2str(new_order))
set(handles.pushbutton7,'Enable','on')

l_c_order = new_order;

%Visualize the previous order
f_plot_even_odd(data_cs(:,:,l_c_month),new_order,'no','yes',handles);

%Visualize the previous de-correlated order
if min(min(isnan(data_cs_dec(:,:,l_c_month)))) == 0
        
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,l_c_month),new_order,'no','yes_dec',handles);
    
else
    
    %Clear and reset axes
    axes(handles.new_axes_3)
    legend off
    reset(handles.new_axes_3)
    colorbar off
    cla
    axis off
    
    
    axes(handles.new_axes_4)
    legend off
    reset(handles.new_axes_4)
    colorbar off
    cla
    axis off
    
    
end

if new_order ~= 0
    
    set(handles.pushbutton6,'Enable','on')
    
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.pushbutton7,'Enable','off')

%Set global variables
global data_cs data_cs_dec l_c_order l_c_month deg_max

%Get the number of current solution
new_order = l_c_order + 1;

set(handles.edit2,'String',num2str(new_order))
set(handles.pushbutton6,'Enable','on')

l_c_order = new_order;

%Visualize the next order
f_plot_even_odd(data_cs(:,:,l_c_month),new_order,'no','yes',handles);

%Visualize the next de-correlated order
if min(min(isnan(data_cs_dec(:,:,l_c_month)))) == 0
        
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,l_c_month),new_order,'no','yes_dec',handles);
    
else
    
    %Clear and reset axes
    axes(handles.new_axes_3)
    legend off
    reset(handles.new_axes_3)
    colorbar off
    cla
    axis off
    
    
    axes(handles.new_axes_4)
    legend off
    reset(handles.new_axes_4)
    colorbar off
    cla
    axis off
    
    
end

if new_order ~= deg_max - 1
    
    set(handles.pushbutton7,'Enable','on')
    
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_pol vis_format data_pol_cs data_pol_sc

if isempty(data_pol_cs) == 1
    errordlg('Polynomial degree is not selected.','Error')
else
    
    if isempty(ishandle(h_pol)) == 1 || ishandle(h_pol) == 0
        
        h_pol     = figure;
        
    else
        
        figure(h_pol)
        
    end
    
    if vis_format == 1
        
        f_plot_cs(data_pol_cs,'linear','no')
        set(h_pol,'Name','Polynomial degree in |C\S|-format')
        set(h_pol,'Units','pixels')
        h_pol_pos = get(h_pol,'Position');
        set(h_pol,'Position',[h_pol_pos(1,1) h_pol_pos(1,2) 800 600]);
        movegui(h_pol,'center')
        
    elseif vis_format == 2
        
        f_plot_sc(data_pol_sc,'linear','no')
        set(h_pol,'Name','Polynomial degree in /S|C\-format')
        set(h_pol,'Units','pixels')
        h_pol_pos = get(h_pol,'Position');
        set(h_pol,'Position',[h_pol_pos(1,1) h_pol_pos(1,2) 800 600]);
        movegui(h_pol,'center')
        
    end
    
end


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_win vis_format data_win_cs data_win_sc

if isempty(data_win_cs) == 1
    errordlg('Window length is not selected.','Error')
else
    
    if isempty(ishandle(h_win)) == 1 || ishandle(h_win) == 0
        
        h_win     = figure;
        
    else
        
        figure(h_win)
        
    end
    
    if vis_format == 1
        
        f_plot_cs(data_win_cs,'linear','no')
        set(h_win,'Name','Window length in |C\S|-format')
        set(h_win,'Units','pixels')
        h_win_pos = get(h_win,'Position');
        set(h_win,'Position',[h_win_pos(1,1) h_win_pos(1,2) 800 600]);
        movegui(h_win,'center')
        
    elseif vis_format == 2
        
        f_plot_sc(data_win_sc,'linear','no')
        set(h_win,'Name','Window length in /S|C\-format')
        set(h_win,'Units','pixels')
        h_win_pos = get(h_win,'Position');
        set(h_win,'Position',[h_win_pos(1,1) h_win_pos(1,2) 800 600]);
        movegui(h_win,'center')
        
    end
    
end


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_por vis_format data_por_cs data_por_sc

if isempty(data_por_cs) == 1
    errordlg('Portion matrix is not selected.','Error')
else
    
    if isempty(ishandle(h_por)) == 1 || ishandle(h_por) == 0
        
        h_por     = figure;
        
    else
        
        figure(h_por)
        
    end
    
    if vis_format == 1
        
        f_plot_cs(data_por_cs,'linear','no')
        set(h_por,'Name','Portion matrix in |C\S|-format')
        set(h_por,'Units','pixels')
        h_por_pos = get(h_por,'Position');
        set(h_por,'Position',[h_por_pos(1,1) h_por_pos(1,2) 800 600]);
        movegui(h_por,'center')
        
    elseif vis_format == 2
        
        f_plot_sc(data_por_sc,'linear','no')
        set(h_por,'Name','Portion matrix in /S|C\-format')
        set(h_por,'Units','pixels')
        h_por_pos = get(h_por,'Position');
        set(h_por,'Position',[h_por_pos(1,1) h_por_pos(1,2) 800 600]);
        movegui(h_por,'center')
        
    end
    
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

%Set global variables
global data_cs data_sc data_pot num_month l_c_month l_c_order vis_format
global LON LAT coastline_lat coastline_lon data_cs_dec data_sc_dec
global data_pot_dec axes_1_lim axes_2_lim

%Get the solution number
new_month     = str2double(get(handles.edit1,'String'));

if new_month > 0 && new_month <= num_month && new_month ~= l_c_month
    
    %Visualize the selected solution
    axes(handles.axes1)
    
    if vis_format == 1
        
        f_plot_cs(data_cs(:,:,new_month),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc(:,:,new_month),'logarithmic','yes')
        
    end
    
    axes_1_lim = caxis;
    
    axes(handles.axes2)
    
    pcolor(LON,LAT,data_pot(:,:,new_month));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside');
    set(gca,'Layer','top')
    
    axes_2_lim = 0.1*caxis;
    
    caxis(axes_2_lim)
    
    f_plot_even_odd(data_cs(:,:,new_month),l_c_order,'no','yes',handles);
    
    %Visualize the selected de-correlated solution
    if min(min(isnan(data_cs_dec(:,:,new_month)))) == 0
        
        axes(handles.axes4)
        
        if vis_format == 1
            
            f_plot_cs(data_cs_dec(:,:,new_month),'logarithmic','yes')
            
        elseif vis_format == 2
            
            f_plot_sc(data_sc_dec(:,:,new_month),'logarithmic','yes')
            
        end
        
        caxis(axes_1_lim)
        
        axes(handles.axes5)
        
        pcolor(LON,LAT,data_pot_dec(:,:,new_month));
        hold on
        plot(coastline_lon,coastline_lat,'-k')
        hold off
        axis image
        shading flat
        colorbar('SouthOutside');
        set(gca,'Layer','top')
        
        caxis(axes_2_lim)
        
        if isempty(findobj('Tag','axes6')) ~= 1
            
            axes(handles.new_axes_3)
            
        end
        
        f_plot_even_odd(data_cs_dec(:,:,new_month),l_c_order,'no','yes_dec',handles);
        
    else
        
        %Clear and reset axes
        axes(handles.axes4)
        reset(handles.axes4)
        colorbar off
        cla
        axis off
        
        axes(handles.axes5)
        reset(handles.axes5)
        colorbar off
        cla
        axis off
        
        if isempty(findobj('Tag','axes6')) == 1
            
            axes(handles.new_axes_3)
            legend off
            reset(handles.new_axes_3)
            colorbar off
            cla
            axis off
            
            
            axes(handles.new_axes_4)
            legend off
            reset(handles.new_axes_4)
            colorbar off
            cla
            axis off
            
        end
        
    end
    
    if new_month == 1 && num_month ~= 1
        
        set(handles.pushbutton3,'Enable','off')
        set(handles.pushbutton4,'Enable','on')
        
    elseif new_month == num_month && num_month ~= 1
        
        set(handles.pushbutton3,'Enable','on')
        set(handles.pushbutton4,'Enable','off')
        
    else
        
        set(handles.pushbutton3,'Enable','on')
        set(handles.pushbutton4,'Enable','on')
        
    end
    
    l_c_month = new_month;
    
elseif new_month <= 0 || new_month > num_month
    
    errordlg('Selected solution not found.','Error')
    set(handles.edit1,'String',num2str(l_c_month))
    
end


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

%Set global variables
global data_cs data_cs_dec l_c_order l_c_month deg_max

%Get the solution number
new_order     = str2double(get(handles.edit2,'String'));

if new_order > -1 && new_order <= deg_max - 1 && new_order ~= l_c_order
    
    %Visualize the selected order
    f_plot_even_odd(data_cs(:,:,l_c_month),new_order,'no','yes',handles);
    
    %Visualize the selected de-correlated order
    if min(min(isnan(data_cs_dec(:,:,l_c_month)))) == 0
        
        if isempty(findobj('Tag','axes6')) ~= 1
            
            axes(handles.new_axes_3)
            
        end
        
        f_plot_even_odd(data_cs_dec(:,:,l_c_month),new_order,'no','yes_dec',handles);
        
    else
        
        %Clear and reset axes
        if isempty(findobj('Tag','axes6')) == 1
                        
            axes(handles.new_axes_3)
            legend off
            reset(handles.new_axes_3)
            colorbar off
            cla
            axis off
            
            
            axes(handles.new_axes_4)
            legend off
            reset(handles.new_axes_4)
            colorbar off
            cla
            axis off
            
            
        end
        
    end

    if new_order == 0 && deg_max ~= 0
        
        set(handles.pushbutton6,'Enable','off')
        set(handles.pushbutton7,'Enable','on')
        
    elseif new_order == deg_max - 1 && deg_max ~= 1
        
        set(handles.pushbutton6,'Enable','on')
        set(handles.pushbutton7,'Enable','off')
        
    else
        
        set(handles.pushbutton6,'Enable','on')
        set(handles.pushbutton7,'Enable','on')
        
    end
    
    l_c_order = new_order;
    
elseif new_order <= -1 || new_order > deg_max - 1
    
    errordlg('Selected order not found.','Error')
    set(handles.edit2,'String',num2str(l_c_order))
    
end


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

%Set global variables
global data_cs data_cs_dec axes_1_lim vis_format l_c_month

set(handles.radiobutton1,'Value',1)
set(handles.radiobutton2,'Value',0)

vis_format = 1;

if isempty(data_cs) == 0
    
    axes(handles.axes1)
    f_plot_cs(data_cs(:,:,l_c_month),'logarithmic','yes')
    
    if min(min(isnan(data_cs_dec(:,:,l_c_month)))) == 0
        
        axes(handles.axes4)
        f_plot_cs(data_cs_dec(:,:,l_c_month),'logarithmic','yes')
        
        caxis(axes_1_lim)
        
    end
    
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

%Set global variables
global data_sc data_sc_dec axes_1_lim vis_format l_c_month

set(handles.radiobutton1,'Value',0)
set(handles.radiobutton2,'Value',1)

vis_format = 2;

if isempty(data_sc) == 0
    
    axes(handles.axes1)
    f_plot_sc(data_sc(:,:,l_c_month),'logarithmic','yes')
    
    if min(min(isnan(data_sc_dec(:,:,l_c_month)))) == 0
        
        axes(handles.axes4)
        f_plot_sc(data_sc_dec(:,:,l_c_month),'logarithmic','yes')
        
        caxis(axes_1_lim)
        
    end
    
end


% --------------------------------------------------------------------
function menu_file_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_data_format_Callback(hObject, eventdata, handles)
% hObject    handle to menu_data_format (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_cs_Callback(hObject, eventdata, handles)
% hObject    handle to menu_cs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_format

data_format = 1;

set(handles.menu_cs,'Checked','on')
set(handles.menu_sc,'Checked','off')
set(handles.menu_nmcs,'Checked','off')


% --------------------------------------------------------------------
function menu_sc_Callback(hObject, eventdata, handles)
% hObject    handle to menu_sc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_format

data_format = 2;

set(handles.menu_cs,'Checked','off')
set(handles.menu_sc,'Checked','on')
set(handles.menu_nmcs,'Checked','off')


% --------------------------------------------------------------------
function menu_nmcs_Callback(hObject, eventdata, handles)
% hObject    handle to menu_nmcs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_format

data_format = 3;

set(handles.menu_cs,'Checked','off')
set(handles.menu_sc,'Checked','off')
set(handles.menu_nmcs,'Checked','on')


% --------------------------------------------------------------------
function menu_import_data_Callback(hObject, eventdata, handles)
% hObject    handle to menu_import_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_from_file_Callback(hObject, eventdata, handles)
% hObject    handle to menu_from_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_format data_cs data_sc data_pot deg_max num_month vis_format
global LON LAT coastline_lat coastline_lon l_c_month l_c_order
global axes_1_lim axes_2_lim data_cs_dec data_sc_dec data_pot_dec file_name
global is_file is_variable

%Initialize variables
l_c_month                    = 1;
l_c_order                    = 0;
data_success                 = 0;

%Open File Selector GUI
[filename, pathname]         = uigetfile('*.mat','File Selector');

%Check if file has been selected
if (filename ~= 0)
    
    %Get the name of file without the extension
    file_name                = filename(1:end - 4);
    is_file                  = 1;
    is_variable              = 0;
    
    %Get the data from selected file
    datafile                 = fullfile(pathname,filename);
    data_temp                = importdata(datafile);
    
    %Test if data format is structure
    if isstruct(data_temp) == 1 || iscell(data_temp) == 1
        errordlg('Selected data should not be a structure or a cell.','Error')
    else
        
        %Get the size of data
        data_size_1              = size(data_temp,1);
        data_size_2              = size(data_temp,2);
        data_size_3              = size(data_temp,3);
        
        %Test if data format agrees with selected format
        switch data_format
            
            case 1
                
                if data_size_1 ~= data_size_2
                    errordlg('Selected data are not in |C\S| format.','Error')
                else
                    
                    %Get data
                    data_cs      = data_temp;
                    data_sc      = f_cs2sc(data_cs);
                    
                    %Successful processing of data
                    data_success = 1;
                    
                end
                
            case 2
                
                if data_size_1 ~= (data_size_2 + 1)/2
                    errordlg('Selected data are not in /S|C\ format.','Error')
                else
                    
                    %Get data and convert them to |C\S| format
                    data_cs      = f_sc2cs(data_temp);
                    data_sc      = data_temp;
                    
                    %Successful processing of data
                    data_success = 1;
                    
                end
                
            case 3
                
                if data_size_2 ~= 4
                    errordlg('Selected data are not in [n,m,C,S] format.','Error')
                else
                    
                    %Get data and convert them to |C\S| format
                    data_cs      = f_nmcs2cs(data_temp);
                    data_sc      = f_nmcs2sc(data_temp);
                    
                    %Successful processing of data
                    data_success = 1;
                    
                end
                
        end
        
    end
    
    %Get data information
    if data_success == 1
        
        %Initialize de-correlated data
        data_cs_dec          = NaN(size(data_cs));
        data_sc_dec          = NaN(size(data_sc));
        
        %Get number of monthly solutions (only for .mat files)
        num_month            = data_size_3;
        
        %Get the maximum degree
        deg_max              = size(data_cs,1) - 1;
        
        %Initialize variables
        data_pot             = zeros(size(LAT,1),size(LAT,2),num_month);
        data_pot_dec         = NaN(size(LAT,1),size(LAT,2),num_month);
        
        %Create a progress bar
        h                    = waitbar(0,'Performing spherical harmonic synthesis...');
        
        for i = 1:num_month
            
            data_pot(:,:,i)  = f_gshs_potential(data_cs(:,:,i));
            
            %Update progress bar
            waitbar(i/num_month,h,['Performing spherical harmonic synthesis... [' num2str(i) '/' num2str(num_month) ']'])
            
        end
        
        %Close progress bar
        close(h)
        
        %Set selected data info in the GUI
        set(handles.text3,'String',num2str(num_month))
        set(handles.text5,'String',num2str(deg_max))
        
        %Change GUI controls
        set(handles.pushbutton3,'Enable','on')
        set(handles.pushbutton4,'Enable','on')
        set(handles.pushbutton6,'Enable','on')
        set(handles.pushbutton7,'Enable','on')
        set(handles.menu_parameters,'Enable','on')
        set(handles.menu_decorrelate,'Enable','on')
        set(handles.menu_export,'Enable','off')
        
        set(handles.edit1,'Enable','on')
        set(handles.edit2,'Enable','on')
        
        set(handles.radiobutton1,'Enable','on')
        set(handles.radiobutton2,'Enable','on')
        
        %Visualize the first solution
        axes(handles.axes1)
        
        if vis_format == 1
            
            f_plot_cs(data_cs(:,:,1),'logarithmic','yes')
            
        elseif vis_format == 2
            
            f_plot_sc(data_sc(:,:,1),'logarithmic','yes')
            
        end
        
        axes_1_lim           = caxis;
        
        axes(handles.axes2)
        
        pcolor(LON,LAT,data_pot(:,:,1));
        hold on
        plot(coastline_lon,coastline_lat,'-k')
        hold off
        axis image
        shading flat
        colorbar('SouthOutside');
        set(gca,'Layer','top')
        
        axes_2_lim           = 0.1*caxis;
        
        caxis(axes_2_lim)
        set(handles.edit1,'String',num2str(1))
        set(handles.pushbutton3,'Enable','off')
        
        if num_month == 1
            
            set(handles.pushbutton4,'Enable','off')
            
        else
            
            set(handles.pushbutton4,'Enable','on')
            
        end
        
        f_plot_even_odd(data_cs(:,:,1),0,'no','yes',handles);
        
        set(handles.edit2,'String',num2str(0))
        set(handles.pushbutton6,'Enable','off')
        
        if deg_max == 0
            
            set(handles.pushbutton7,'Enable','off')
            
        else
            
            set(handles.pushbutton7,'Enable','on')
            
        end
        
        %Clear and reset axes
        axes(handles.axes4)
        reset(handles.axes4)
        colorbar off
        cla
        axis off
        
        axes(handles.axes5)
        reset(handles.axes5)
        colorbar off
        cla
        axis off
        
        axes(handles.new_axes_3)
        legend off
        reset(handles.new_axes_3)
        colorbar off
        cla
        axis off
        
        axes(handles.new_axes_4)
        legend off
        reset(handles.new_axes_4)
        colorbar off
        cla
        axis off
        
    end
    
end


% --------------------------------------------------------------------
function menu_from_workspace_Callback(hObject, eventdata, handles)
% hObject    handle to menu_from_workspace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Open GUI
select_workspace


% --------------------------------------------------------------------
function menu_export_Callback(hObject, eventdata, handles)
% hObject    handle to menu_export (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_to_file_Callback(hObject, eventdata, handles)
% hObject    handle to menu_to_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_cs_dec data_sc_dec file_name var_name is_file is_variable data_format

if is_file == 1
    
    %Create the suggested variable name from the input file name
    file_name_dec            = [file_name '_dec'];
    
elseif is_variable == 1
    
    %Create the suggested variable name from the input variable name
    file_name_dec            = [var_name '_dec'];
    
end

if data_format == 1
    
    var_dec                 = data_cs_dec;
    
elseif data_format == 2
    
    var_dec                 = data_sc_dec;
    
elseif data_format == 3
    
    var_dec                 = f_cs2nmcs(data_cs_dec);
    
end

dlg_options.WindowStyle     = 'modal';
dlg_out                     = inputdlg('Select file name:','Export data to file',[1 60],{file_name_dec},dlg_options);

if isempty(dlg_out) ~= 1
    
    save(cell2mat(dlg_out),'var_dec')
    
    helpdlg(strcat({'File '},dlg_out,{'.mat is exported to current folder.'}),'Save data to file')
    
end


% --------------------------------------------------------------------
function menu_to_workspace_Callback(hObject, eventdata, handles)
% hObject    handle to menu_to_workspace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_cs_dec data_sc_dec file_name var_name is_file is_variable data_format

if is_file == 1
    
    %Create the suggested variable name from the input file name
    var_name_dec            = [file_name '_dec'];
    
elseif is_variable == 1
    
    %Create the suggested variable name from the input variable name
    var_name_dec            = [var_name '_dec'];
    
end

if data_format == 1
    
    var_dec                 = data_cs_dec;
    
elseif data_format == 2
    
    var_dec                 = data_sc_dec;
    
elseif data_format == 3
    
    var_dec                 = f_cs2nmcs(data_cs_dec);
    
end

dlg_options.WindowStyle     = 'modal';
dlg_out                     = inputdlg('Select variable name:','Export data to workspace',[1 60],{var_name_dec},dlg_options);

if isempty(dlg_out) ~= 1
    
    assignin('base',cell2mat(dlg_out),var_dec)
    
    helpdlg(strcat({'Variable '},dlg_out,{' is saved to workspace.'}),'Save data to workspace')
    
end


% --------------------------------------------------------------------
function menu_parameters_Callback(hObject, eventdata, handles)
% hObject    handle to menu_parameters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_portion_Callback(hObject, eventdata, handles)
% hObject    handle to menu_portion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_por

%Close polynomial plot if exists
if ishandle(h_por) == 1
    
    close(h_por)
    
end

%Load polynomial parameters GUI
select_portion


% --------------------------------------------------------------------
function menu_window_Callback(hObject, eventdata, handles)
% hObject    handle to menu_window (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_win

%Close polynomial plot if exists
if ishandle(h_win) == 1
    
    close(h_win)
    
end

%Load polynomial parameters GUI
select_window


% --------------------------------------------------------------------
function menu_polynomial_Callback(hObject, eventdata, handles)
% hObject    handle to menu_polynomial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global h_pol

%Close polynomial plot if exists
if ishandle(h_pol) == 1
    
    close(h_pol)
    
end

%Load polynomial parameters GUI
select_polynomial


% --------------------------------------------------------------------
function menu_por_flag_Callback(hObject, eventdata, handles)
% hObject    handle to menu_por_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_por_flag_0_Callback(hObject, eventdata, handles)
% hObject    handle to menu_por_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_por_flag

data_por_flag = 0;

set(handles.menu_por_flag_0,'Checked','on')
set(handles.menu_por_flag_1,'Checked','off')


% --------------------------------------------------------------------
function menu_por_flag_1_Callback(hObject, eventdata, handles)
% hObject    handle to menu_por_flag_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_por_flag

data_por_flag = 1;

set(handles.menu_por_flag_0,'Checked','off')
set(handles.menu_por_flag_1,'Checked','on')


% --------------------------------------------------------------------
function menu_decorrelate_Callback(hObject, eventdata, handles)
% hObject    handle to menu_decorrelate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_current_Callback(hObject, eventdata, handles)
% hObject    handle to menu_current (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global data_cs data_pol_cs data_win_cs data_por_cs data_cs_dec
global data_sc_dec data_pot_dec LON LAT vis_format l_c_month l_c_order
global coastline_lat coastline_lon axes_1_lim axes_2_lim 
global data_por_flag win_choice data_win_por

%Check if all de-correlation parameters have been selected
if isempty(data_pol_cs) == 1 || isempty(data_win_cs) == 1 || isempty(data_por_cs) == 1
    
    if isempty(data_pol_cs) == 1
        errordlg('Polynomial degree is not selected.','Error')
    elseif isempty(data_win_cs) == 1
        errordlg('Window length is not selected.','Error')
    elseif isempty(data_por_cs) == 1
        errordlg('Portion matrix is not selected.','Error')
    end
    
else
    
    if strcmp(get(handles.menu_por_flag_1,'Checked'),'on') == 1 && win_choice == 3 && data_win_por == 0
        
        uiwait(warndlg({'De-correlation might be inaccurate due to parameter inconsistencies. Inconsistent parameters:','Fitting coefficients -> Use only inside portion','Window length -> Window 3 -> Use portion matrix (Not checked)'},'Warning'));
        
    end
    
    %De-correlate current solution
    data_cs_dec(:,:,l_c_month)  = f_dec_filter(data_cs(:,:,l_c_month),[],data_por_cs,data_win_cs,data_pol_cs,data_por_flag);
    data_sc_dec                 = f_cs2sc(data_cs_dec);
    
    %Perform spherical harmonic synthesis
    data_pot_dec(:,:,l_c_month) = f_gshs_potential(data_cs_dec(:,:,l_c_month));
    
    set(handles.menu_export,'Enable','on')
    
    %Visualize the current solution
    axes(handles.axes4)
    
    if vis_format == 1
        
        f_plot_cs(data_cs_dec(:,:,l_c_month),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc_dec(:,:,l_c_month),'logarithmic','yes')
        
    end
    
    caxis(axes_1_lim)
    
    axes(handles.axes5)
    
    pcolor(LON,LAT,data_pot_dec(:,:,l_c_month));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside');
    set(gca,'Layer','top')
    
    caxis(axes_2_lim)
    
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,l_c_month),l_c_order,'no','yes_dec',handles);
    
end


% --------------------------------------------------------------------
function menu_all_Callback(hObject, eventdata, handles)
% hObject    handle to menu_por_flag_0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global num_month data_cs data_pol_cs data_win_cs data_por_cs data_cs_dec
global data_sc_dec data_pot_dec LON LAT vis_format l_c_month l_c_order
global coastline_lat coastline_lon axes_1_lim axes_2_lim
global data_por_flag

%Check if all de-correlation parameters have been selected
if isempty(data_pol_cs) == 1 || isempty(data_win_cs) == 1 || isempty(data_por_cs) == 1
    
    if isempty(data_pol_cs) == 1
        errordlg('Polynomial degree is not selected.','Error')
    elseif isempty(data_win_cs) == 1
        errordlg('Window length is not selected.','Error')
    elseif isempty(data_por_cs) == 1
        errordlg('Portion matrix is not selected.','Error')
    end
    
else
    
    %Create a progress bar
    h                       = waitbar(0,'Applying de-correlation filter...');
    
    %De-correlate all solutions
    for i = 1:num_month
        
        data_cs_dec(:,:,i)  = f_dec_filter(data_cs(:,:,i),NaN,data_por_cs,data_win_cs,data_pol_cs,data_por_flag);
        
        %Update progress bar
        waitbar(i/num_month,h,['Applying de-correlation filter... [' num2str(i) '/' num2str(num_month) ']'])
        
    end
    
    %Close progress bar
    close(h)
    
    data_sc_dec             = f_cs2sc(data_cs_dec);
    
    %Create a progress bar
    h                       = waitbar(0,'Performing spherical harmonic synthesis...');
    
    %Perform spherical harmonic synthesis
    for i = 1:num_month
        
        data_pot_dec(:,:,i) = f_gshs_potential(data_cs_dec(:,:,i));
        
        %Update progress bar
        waitbar(i/num_month,h,['Performing spherical harmonic synthesis... [' num2str(i) '/' num2str(num_month) ']'])
        
    end
    
    %Close progress bar
    close(h)
    
    set(handles.menu_export,'Enable','on')
    
    %Visualize the current solution
    axes(handles.axes4)
    
    if vis_format == 1
        
        f_plot_cs(data_cs_dec(:,:,l_c_month),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc_dec(:,:,l_c_month),'logarithmic','yes')
        
    end
    
    caxis(axes_1_lim)
    
    axes(handles.axes5)
    
    pcolor(LON,LAT,data_pot_dec(:,:,l_c_month));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside');
    set(gca,'Layer','top')
    
    caxis(axes_2_lim)
    
    if isempty(findobj('Tag','axes6')) ~= 1
        
        axes(handles.new_axes_3)
        
    end
    
    f_plot_even_odd(data_cs_dec(:,:,l_c_month),l_c_order,'no','yes_dec',handles);
    
end
