function varargout = select_workspace(varargin)
% SELECT_WORKSPACE MATLAB code for select_workspace.fig
%      SELECT_WORKSPACE, by itself, creates a new SELECT_WORKSPACE or raises the existing
%      singleton*.
%
%      H = SELECT_WORKSPACE returns the handle to a new SELECT_WORKSPACE or the handle to
%      the existing singleton*.
%
%      SELECT_WORKSPACE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECT_WORKSPACE.M with the given input arguments.
%
%      SELECT_WORKSPACE('Property','Value',...) creates a new SELECT_WORKSPACE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before select_workspace_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to select_workspace_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help select_workspace

% Last Modified by GUIDE v2.5 30-Oct-2017 17:46:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @select_workspace_OpeningFcn, ...
                   'gui_OutputFcn',  @select_workspace_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before select_workspace is made visible.
function select_workspace_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to select_workspace (see VARARGIN)

% Choose default command line output for select_workspace
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes select_workspace wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%Set global variables
global data_format workspace_var

%Move GUI at the center of screen
movegui(gcf,'center')

%Get the information of all variables in the base workspace
workspace_info               = evalin('base','whos');
workspace_var                = evalin('base','who');
var_num                      = size(workspace_info,1);

%Initialize variables
var_mask                     = zeros(var_num,1);

%Set the title for the uipanel1 according to selected format
switch data_format
    
    case 1
        
        set(handles.uipanel1,'Title','Workspace variables in |C\S| format')
        
    case 2
        
        set(handles.uipanel1,'Title','Workspace variables in /S|C\ format')
        
    case 3
        
        set(handles.uipanel1,'Title','Workspace variables in [n,m,C,S] format')
        
end

%Get only the variables with the selected format
for i = 1:var_num
    
    if strcmp(workspace_info(i,1).class,'struct') == 0 && strcmp(workspace_info(i,1).class,'cell') == 0
        
        size_cur             = workspace_info(i,1).size;
        
        if data_format == 1 && size_cur(1,1) == size_cur(1,2) && max(size_cur) > 1
            
            var_mask(i,1)    = 1;
            
        elseif data_format == 2 && size_cur(1,1) == (size_cur(1,2) + 1)/2 && max(size_cur) > 1
            
            var_mask(i,1)    = 1;
            
        elseif data_format == 3 && size_cur(1,2) == 4 && max(size_cur) > 1
            
            var_mask(i,1)    = 1;
            
        end
        
    end
    
end

workspace_var(var_mask == 0) = [];

%Set all the variable names to the popup menus
set(handles.popupmenu1,'String',['Select variable';workspace_var])


% --- Outputs from this function are returned to the command line.
function varargout = select_workspace_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Set global variables
global num_month deg_max data_cs data_sc data_format vis_format workspace_var 
global LON LAT data_pot coastline_lon coastline_lat h1_pos l_c_month l_c_order
global data_cs_dec data_sc_dec data_pot_dec var_name is_file is_variable
global axes_1_lim axes_2_lim

%Initialize variables
l_c_month               = 1;
l_c_order               = 0;

%Get selected workspace variable
var_value               = get(handles.popupmenu1,'Value');

if var_value ~= 1
    
    %Get the variable name
    var_name            = cell2mat(workspace_var(var_value - 1,1));
    is_file             = 0;
    is_variable         = 1;
    
    data_temp           = evalin('base',cell2mat(workspace_var(var_value - 1,1)));
    
    if data_format == 1
        
        data_cs         = data_temp;
        data_sc         = f_cs2sc(data_temp);
        
    elseif data_format == 2
        
        data_cs         = f_sc2cs(data_temp);
        data_sc         = data_temp;
        
    elseif data_format == 3
        
        data_cs         = f_nmcs2cs(data_temp);
        data_sc         = f_nmcs2sc(data_temp);
        
    end
    
    %Initialize de-correlated data
    data_cs_dec         = NaN(size(data_cs));
    data_sc_dec         = NaN(size(data_sc));
    
    %Get number of monthly solutions (only for .mat files)
    num_month           = size(data_cs,3);
    
    %Get the maximum degree
    deg_max             = size(data_cs,1) - 1;
    
    %Initialize variables
    data_pot            = zeros(size(LAT,1),size(LAT,2),num_month);
    data_pot_dec        = NaN(size(LAT,1),size(LAT,2),num_month);
    
    %Create a progress bar
    h                   = waitbar(0,'Performing spherical harmonic synthesis...');
    
    for i = 1:num_month
        
        data_pot(:,:,i) = f_gshs_potential(data_cs(:,:,i));
        
        %Update progress bar
        waitbar(i/num_month,h,['Performing spherical harmonic synthesis... [' num2str(i) '/' num2str(num_month) ']'])
        
    end
    
    %Close progress bar
    close(h)
    
    %Set selected data info in the main GUI
    shade_h             = findobj('Tag','SHADE');
    shade_gui           = guidata(shade_h);
    
    set(shade_gui.text3,'String',num2str(num_month))
    set(shade_gui.text5,'String',num2str(deg_max))
    
    set(shade_gui.pushbutton3,'Enable','on')
    set(shade_gui.pushbutton4,'Enable','on')
    set(shade_gui.pushbutton6,'Enable','on')
    set(shade_gui.pushbutton7,'Enable','on')
    set(shade_gui.menu_parameters,'Enable','on')
    set(shade_gui.menu_decorrelate,'Enable','on')
    
    set(shade_gui.edit1,'Enable','on')
    set(shade_gui.edit2,'Enable','on')
    
    set(shade_gui.radiobutton1,'Enable','on')
    set(shade_gui.radiobutton2,'Enable','on')
    
    %Visualize the first solution
    axes(shade_gui.axes1)
    
    if vis_format == 1
        
        f_plot_cs(data_cs(:,:,1),'logarithmic','yes')
        
    elseif vis_format == 2
        
        f_plot_sc(data_sc(:,:,1),'logarithmic','yes')
        
    end
    
    axes_1_lim          = caxis;
    
    axes(shade_gui.axes2)
    
    pcolor(LON,LAT,data_pot(:,:,1));
    hold on
    plot(coastline_lon,coastline_lat,'-k')
    hold off
    axis image
    shading flat
    colorbar('SouthOutside')
    set(gca,'Layer','top')
    
    axes_2_lim          = 0.1*caxis;
    
    caxis(axes_2_lim)
    
    set(shade_gui.edit1,'String',num2str(1))
    set(shade_gui.pushbutton3,'Enable','off')
    
    if num_month == 1
        
        set(shade_gui.pushbutton4,'Enable','off')
        
    else
        
        set(shade_gui.pushbutton4,'Enable','on')
        
    end
        
    f_plot_even_odd(data_cs(:,:,1),0,'no','yes',shade_gui);
    
    set(shade_gui.edit2,'String',num2str(0))
    set(shade_gui.pushbutton6,'Enable','off')
    
    if deg_max == 0
        
        set(shade_gui.pushbutton7,'Enable','off')
        
    else
        
        set(shade_gui.pushbutton7,'Enable','on')
        
    end
    
    %Clear and reset axes
    axes(shade_gui.axes4)
    reset(shade_gui.axes4)
    colorbar off
    cla
    axis off
    
    axes(shade_gui.axes5)
    reset(shade_gui.axes5)
    colorbar off
    cla
    axis off
    
    axes(shade_gui.new_axes_3)
    legend off
    reset(shade_gui.new_axes_3)
    colorbar off
    cla
    axis off
    
    axes(shade_gui.new_axes_4)
    legend off
    reset(shade_gui.new_axes_4)
    colorbar off
    cla
    axis off
    
    %Close select_workspace GUI
    close(select_workspace)
    
else
    
    errordlg('Please select a workspace variable.','Error')
    
end
