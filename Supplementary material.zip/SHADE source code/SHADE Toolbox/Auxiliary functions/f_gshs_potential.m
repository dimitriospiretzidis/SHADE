function [W] = f_gshs_potential(CS)
%%
% F_GSHS_POTENTIAL calculates the gravitational potential of a spherical
% harmonic coefficient set by performing global spherical harmonic
% synthesis on a 1� grid.
%
% HOW: [W] = f_gshs_potential(CS)
%
% Input:  CS          [n x n] coefficients in |C\S| format.
%
% Output: W       [180 x 360] global rectangular grid (phi = [-89.5 89.5],
%                             lamda = [-179.5 179.5]) of gravitational
%                             potential in m^2/s^2.
%
% Dimitrios Piretzidis
% Department of Geomatics Engineering, UofC
% 05/10/2017

% required m-files: f_cs2c_s.m, f_nlegendre_fun_rec_fast.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1 ; error('Wrong number of input arguments.') ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> argument should be a |C\S| matrix.')
end

%% Start the algorithm

%Define constants
R                          = 6378136.3;       %Earth's radius [m]
GM                         = 3.986004415e+14; %Product of gravitational constant and Earth's mass
coef                       = GM/R;

%Break input matrix into C and S components
[C,S]                      = f_cs2c_s(CS,0);

%Maximum degree
deg_max                    = size(CS,1) - 1;

%Create a global grid
grid_step                  = 1;
lamda                      = (-180 + grid_step/2:grid_step:180 - grid_step/2);
phi                        = (90 - grid_step/2:-grid_step:-90+grid_step/2);

%Force variables to have a column-vector format
lamda                      = lamda(:);
phi                        = phi(:);

%Set up degree and order vectors and matrices
m                          = 0:deg_max;
mlamda                     = bsxfun(@times,m,lamda)';

%Calculate cosine and sine matrices
COS_mlamda                 = cosd(mlamda);
SIN_mlamda                 = sind(mlamda);

%Calculate fully normalized Legendre functions matrix
P_nm_full                  = squeeze(f_nlegendre_fun_rec_fast(deg_max,deg_max,sind(phi),'full'));
P_nm_full                  = permute(P_nm_full,[2 3 1]);

%Initialize variables
A_nm                       = zeros(size(phi,1),deg_max + 1);
B_nm                       = zeros(size(phi,1),deg_max + 1);

%Prepare matrices for spherical harmonic synthesis
for i = 0:deg_max
    
    C_nm                   = C(:,i + 1);
    S_nm                   = S(:,i + 1);
    P_nm                   = squeeze(P_nm_full(:,i + 1,:))';
    A_nm(:,i + 1)          = P_nm*C_nm;
    B_nm(:,i + 1)          = P_nm*S_nm;
    
end

%Perform spherical harmonic synthesis
W                          = coef*(A_nm*COS_mlamda + B_nm*SIN_mlamda);

end
