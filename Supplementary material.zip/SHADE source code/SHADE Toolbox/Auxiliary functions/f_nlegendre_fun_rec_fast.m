function [P_nm] = f_nlegendre_fun_rec_fast(n,m,t,which_degree)
%%
% F_NLEGENDRE_FUN_REC_FAST calculates the fully normalized associated
% Legendre function of degree n and order m using recursive formulas.
%
% HOW: [P_nm] = f_nlegendre_fun_rec_fast(n,m,t,which_degree)
%
% Input: n                     [1 x 1] degree of Legendre function.
%
%        m                     [1 x 1] order of Legendre function.
%
%        t                     [k x p] Legendre function input argument;
%                                      usually is cos(theta) or
%                                      sin(lambda).
%
%        which_degree                  (optional) output degrees. Options:
%                                      - 'current' (default) returns only 
%                                                  the Legendre function of
%                                                  degree n and order m. 
%                                      - 'full'    returns the full 
%                                                  Legendre function
%                                                  matrix.
%
% Output: P_nm [k x p x (n+1) x (m+1)] Legendre function matrix
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 30/12/2014
%
% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 4 && nargin ~= 3; error('Wrong number of input arguments.') ; end
if nargin == 3               ; which_degree = 'current'                  ; end

if isscalar(n) == 0
    error('<n> should be a scalar.')
end

if isscalar(m) == 0
    error('<m> should be a scalar.')
end

if strcmp(which_degree,'current') == 0 && strcmp(which_degree,'full') == 0
    error('<which_degree> should be ''current'' or ''full''.')
end

%Get size of input data
[i_max,j_max]               = size(t);

%Check if output matrix is very large
if i_max*j_max*(n+1)*(m+1) > 2^31
    
    error('Too many elements. Consider using f_nlegendre_fun_rec')
    
end

%% Start the algorithm

%Initialize P_nm for the recursive algorithm
P_nm_c                      = zeros(i_max,j_max,n + 1,m + 1);
P_nm_c(:,:,1,1)             = 1;
P_nm_c(:,:,2,1)             = sqrt(3).*t;
P_nm_c(:,:,2,2)             = sqrt(3).*sqrt(1 - t.^2);

%Recursively compute the elements of the diagonal until degree m
for i = 3:m+1
    
    nn                      = i - 1;
    P_nm_c(:,:,i,i)         = sqrt((2*nn + 1)./(2*nn)).*sqrt(1 - t.^2).*P_nm_c(:,:,i - 1,i - 1);
    
end

%Recursively compute P(m+1,m)
for j = 3:m+2
    
    if j <= n + 1
        
        nn                  = j - 1;
        P_nm_c(:,:,j,j-1)   = sqrt(2*nn + 1).*t.*P_nm_c(:,:,j - 1,j - 1);
        
    end
    
end

%Recursively compute P(n,m)
for j = 1:m+1
    
    mm                      = j - 1;
    
    for i = j+2:n+1
        
        nn                  = i - 1;
        P_nm_c(:,:,i,j)     = sqrt(((2*nn - 1).*(2*nn + 1))./((nn - mm).*(nn + mm))).*t.*P_nm_c(:,:,i - 1,j) - sqrt(((2*nn + 1).*(nn + mm - 1).*(nn - mm - 1))./((2*nn - 3).*(nn + mm).*(nn - mm))).*P_nm_c(:,:,i - 2,j);
        
    end
    
end

%Get the Legendre function
if strcmp(which_degree,'full')
    
    P_nm                    = P_nm_c;
    
elseif strcmp(which_degree,'current')
    
    P_nm                    = P_nm_c(:,:,n + 1,m + 1);
    
end

end
