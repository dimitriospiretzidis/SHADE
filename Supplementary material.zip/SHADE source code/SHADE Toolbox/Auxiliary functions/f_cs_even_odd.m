function [R] = f_cs_even_odd(CS)
%%
% F_CS_EVEN_ODD returns the series of coefficients along a specific order,
% for all orders. The even- and odd-degree coefficient series are also
% derived.
%
% HOW: [R] = f_cs_even_odd(CS)
%
% Input:  CS           [n x n] coefficients in |C\S| format.
%
% Output: R            [n x 1] output structure.
%         R.x_even_odd [n x 1] all degrees.
%         R.x_even     [n x 1] even degrees.
%         R.x_odd      [n x 1] odd degrees.
%         R.C_even_odd [n x 1] C coefficients of all-degree series.
%         R.C_even     [n x 1] C coefficients of even-degree series.
%         R.C_odd      [n x 1] C coefficients of odd-degree series.
%         R.S_even_odd [n x 1] S coefficients of all-degree series.
%         R.S_even     [n x 1] S coefficients of even-degree series.
%         R.S_odd      [n x 1] S coefficients of odd-degree series.
%
% Dimitrios Piretzidis
% Department of Geomatics Engineering, UofC
% 27/09/2017

% required m-files: f_cs2c_s.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1 ; error('Wrong number of input arguments.') ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> argument should be a |C\S| matrix.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max                   = size(CS,1)-1;

%Break input matrix into C and S components
[C,S]                     = f_cs2c_s(CS);

%Initialize output structure
R(deg_max + 1)            = struct();

%Perform the calculations for all degrees
for i = 0:deg_max
    
    %Extract both even and odd degrees
    R(i+1).x_even_odd     = (i:1:deg_max);
    R(i+1).C_even_odd     = C(R(i+1).x_even_odd+1,i+1);
    
    if i ~= 0
        
        R(i+1).S_even_odd = S(R(i+1).x_even_odd+1,i+1);
        
    end
    
    if mod(i,2) == 0
        
        %Extract only even degrees
        R(i+1).x_even     = (i:2:deg_max);
        R(i+1).x_odd      = (i+1:2:deg_max);
        
    elseif mod(i,2) == 1
        
        %Extract only odd degrees
        R(i+1).x_odd      = (i:2:deg_max);
        R(i+1).x_even     = (i+1:2:deg_max);
        
    end
    
    %Compute only even coefficients
    R(i+1).C_even         = C(R(i+1).x_even+1,i+1);
    
    if i ~= 0
        
        R(i+1).S_even     = S(R(i+1).x_even+1,i+1);
        
    end
    
    %Compute only odd coefficients
    R(i+1).C_odd          = C(R(i+1).x_odd+1,i+1);
    
    if i ~= 0
        
        R(i+1).S_odd      = S(R(i+1).x_odd+1,i+1);
        
    end
    
    %Force data to have a column-vector format
    R(i+1).x_even_odd     = R(i+1).x_even_odd(:);
    R(i+1).C_even_odd     = R(i+1).C_even_odd(:);
    R(i+1).x_even         = R(i+1).x_even(:);
    R(i+1).x_odd          = R(i+1).x_odd(:);
    R(i+1).x_odd          = R(i+1).x_odd(:);
    R(i+1).x_even         = R(i+1).x_even(:);
    R(i+1).C_even         = R(i+1).C_even(:);
    R(i+1).C_odd          = R(i+1).C_odd(:);
    
    if i ~= 0
        
        R(i+1).S_even_odd = R(i+1).S_even_odd(:);
        R(i+1).S_even     = R(i+1).S_even(:);
        R(i+1).S_odd      = R(i+1).S_odd(:);
        
    end
    
end

%Force output data to have a column-vector format
R                         = R(:);

end
