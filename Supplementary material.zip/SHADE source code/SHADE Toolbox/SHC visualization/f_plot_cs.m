function [] = f_plot_cs(CS,num_scale,gui_axes)
%%
% F_PLOT_CS returns the plot of a |C\S| matrix.
%
% HOW: f_plot_cs(CS,num_scale)
%      f_plot_cs(CS,num_scale,gui_axes)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        num_scale              numerical scale of plot. Options:
%                               - 'linear'      linear scale.
%                               - 'logarithmic' logarithmic scale.
%
%        gui_axes               (optional) plot results in a GUI axes.
%                               Options:
%                               - 'no'  (default) opens a figure.
%                               - 'yes' handles a default GUI axes.
%
% Output: none
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 02/02/2015

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2 && nargin ~= 3; error('Wrong number of input arguments.'); end
if nargin == 2               ; gui_axes = 'no'                          ; end

if strcmp(num_scale,'linear') == 0 && strcmp(num_scale,'logarithmic') == 0
    error('<num_scale> should be ''linear'' or ''logarithmic''.')
end

if strcmp(gui_axes,'yes') == 0 && strcmp(gui_axes,'no') == 0
    error('<gui_axes> should be ''yes'' or ''no''.')
end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max         = size(CS,1) - 1;

if strcmp(num_scale,'linear') == 1
    
    h0          = imagesc(0:deg_max,0:deg_max,CS);
    
elseif strcmp(num_scale,'logarithmic') == 1
    
    CS(CS == 0) = NaN;
    CS          = abs(CS);
    
    h0          = imagesc(0:deg_max,0:deg_max,log10(CS));
    
end

if strcmp(gui_axes,'no') == 1
    
    h1          = colorbar;
    
elseif strcmp(gui_axes,'yes') == 1
    
    h1          = colorbar('SouthOutside');
    
end

shading flat
axis square
axis([-0.5 deg_max+0.75 -0.5 deg_max+0.75])
set(h0,'AlphaData',~isnan(CS))
colormap('jet')

if strcmp(gui_axes,'no') == 1
    
    set(gca,'FontSize',30,'LineWidth',2)
    set(gcf,'Name','Spherical Harmonic Coefficients in |C\S|-format')
    set(h1,'fontsize',30);
    
    %Insert axes labels (2 sets are provided)
    
    %1st set - Default formatting
    xlabel('S_n_m Degree | C_n_m Order','Fontsize',30)
    ylabel('C_n_m Degree | (S_n_m Order - 1)','Fontsize',30)
    
    %2nd set - LaTeX formatting
    %xlabel('$S_{n,m}$\hspace{2mm} Degree $\mid$ $C_{n,m}$\hspace{2mm} Order','Fontsize',25,'Interpreter','Latex')
    %ylabel('$C_{n,m}$\hspace{2mm} Degree $\mid$ ($S_{n,m}$\hspace{2mm} Order - 1)','Fontsize',25,'Interpreter','Latex')
    
end

end
