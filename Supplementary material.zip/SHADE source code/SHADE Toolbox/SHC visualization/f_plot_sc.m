function [] = f_plot_sc(SC,num_scale,gui_axes)
%%
% F_PLOT_SC returns the plot of a /S|C\ matrix.
%
% HOW: f_plot_sc(SC,num_scale)
%      f_plot_sc(SC,num_scale,gui_axes)
%
% Input: SC           [n x 2*n-1] /S|C\ matrix.
%
%        num_scale              numerical scale of plot. Options:
%                               - 'linear'      linear scale.
%                               - 'logarithmic' logarithmic scale.
%
%        gui_axes               (optional) plot results in a GUI axes.
%                               Options:
%                               - 'no'  (default) opens a figure.
%                               - 'yes' handles a default GUI axes.
%
% Output: none
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 02/02/2015

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2 && nargin ~= 3; error('Wrong number of input arguments.'); end
if nargin == 2               ; gui_axes = 'no'                          ; end

if strcmp(num_scale,'linear') == 0 && strcmp(num_scale,'logarithmic') == 0
    error('<num_scale> should be ''linear'' or ''logarithmic''')
end

if strcmp(gui_axes,'yes') == 0 && strcmp(gui_axes,'no') == 0
    error('<gui_axes> should be ''yes'' or ''no''.')
end

if size(SC,1) ~= (size(SC,2) + 1)/2
    error('<SC> should be a matrix in /S|C\ format')
end

%% Start the algorithm

%Maximum degree of input SC matrix
deg_max         = size(SC,1) - 1;

if strcmp(num_scale,'linear') == 1
    
    h0          = imagesc(-deg_max:deg_max,0:deg_max,SC);
    
elseif strcmp(num_scale,'logarithmic') == 1
    
    SC(SC == 0) = NaN;
    SC          = abs(SC);
    
    h0          = imagesc(-deg_max:deg_max,0:deg_max,log10(SC));
    
end

if strcmp(gui_axes,'no') == 1
    
    h1          = colorbar;
    
elseif strcmp(gui_axes,'yes') == 1
    
    h1          = colorbar('SouthOutside');
    
end

shading flat
axis image
axis([-(deg_max+0.5) deg_max+0.75 -0.5 deg_max+0.75])
set(h0,'AlphaData',~isnan(SC))
colormap('jet')

if strcmp(gui_axes,'no') == 1
    
    set(gca,'FontSize',30,'LineWidth',2)
    set(gcf,'Name','Spherical Harmonic Coefficients in /S|C\-format')
    set(h1,'Fontsize',30);
    
    %Insert axes labels (2 sets are provided)
    
    %1st set - Default formatting
    xlabel('\leftarrow S_n_m Order | C_n_m Order \rightarrow','Fontsize',30)
    ylabel('S_n_m Degree | C_n_m Degree','Fontsize',30)
    
    %2nd set - LaTeX formatting
    %xlabel('$\leftarrow$ $S_{n,m}$\hspace{2mm} Order $\mid$ $C_{n,m}$\hspace{2mm} Order $\rightarrow$','Fontsize',25,'Interpreter','Latex')
    %ylabel('$S_{n,m}$\hspace{2mm} Degree $\mid$ $C_{n,m}$\hspace{2mm} Degree','Fontsize',25,'Interpreter','Latex')
    
end

end
