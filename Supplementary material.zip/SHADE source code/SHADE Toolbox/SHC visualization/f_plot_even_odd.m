function [R] = f_plot_even_odd(CS,order,subplots,gui_axes,handles)
%%
% F_PLOT_EVEN_ODD returns a plot of an even/odd-degree series for a
% specific order.
%
% HOW: [R] = f_plot_even_odd(CS,order)
%      [R] = f_plot_even_odd(CS,order,subplots)
%      [R] = f_plot_even_odd(CS,order,subplots,gui_axes,handles)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        order          [1 x 1] order of plotted coefficient series.
%
%        subplots               (optional) results are given in subplots.
%                               Options:
%                               - 'no'  (default) creates two figures.
%                               - 'yes' creates one figure with two
%                                       suplots.
%
%        gui_axes               (optional) plot results in a GUI axes.
%                               Options:
%                               - 'no'      (default) results plotted in a
%                                           new figure.
%                               - 'yes'     results (correlated series) are
%                                           plotted in SHADE GUI axes.
%                               - 'yes_dec' results (de-correlated series)
%                                           are plotted in SHADE GUI axes.
%
%        handles        [1 x 1] (optional) axes structure.
%
% Output: R             [k x 1] output structure.
%         R.x_even_odd  [k x 1] all degrees.
%         R.x_even      [k x 1] even degrees.
%         R.x_odd       [k x 1] odd degrees.
%         R.C_even_odd  [k x 1] C coefficients of all-degree series.
%         R.C_even      [k x 1] C coefficients of even-degree series.
%         R.C_odd       [k x 1] C coefficients of odd-degree series.
%         R.S_even_odd  [k x 1] S coefficients of all-degree series.
%         R.S_even      [k x 1] S coefficients of even-degree series.
%         R.S_odd       [k x 1] S coefficients of odd-degree series.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_cs_even_odd.m

%% Revision history

%% Remarks

%% Input check

if nargin <  2 || nargin > 5 ; error('Wrong number of input arguments.')       ; end
if nargin == 3               ; handles = 'no'; gui_axes = 'no'                 ; end
if nargin == 2               ; handles = 'no'; gui_axes = 'no'; subplots = 'no'; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(order) ~= 1
    error('<order> should be a scalar.')
end

if strcmp(subplots,'yes') == 0 && strcmp(subplots,'no') == 0
    error('<subplots> should be ''yes'' or ''no''.')
end

if strcmp(gui_axes,'yes') == 0 && strcmp(gui_axes,'yes_dec') == 0 && strcmp(gui_axes,'no') == 0
    error('<gui_axes> should be ''yes'', ''yes_dec'' or ''no''.')
end

if strcmp(gui_axes,'yes') == 1 && nargin == 3
    error('<handles> is missing.')
end

if strcmp(gui_axes,'yes_dec') == 1 && nargin == 3
    error('<handles> is missing.')
end

%% Start the algorithm

%Set global variables
global new_axes_1_lim new_axes_2_lim pow10_str_l_c pow10_l_c

%Maximum degree of input CS matrix
deg_max     = size(CS,1)-1;

%Extract data for all orders
R_all       = f_cs_even_odd(CS);

%Get the data for the selected order
R           = R_all(order + 1);

%Extract the order of magnitude
if order ~= 0
    
    pow10   = 10^(floor(log10(max(abs([R.C_even_odd ; R.S_even_odd])))));
    
else
    
    pow10   = 10^(floor(log10(max(abs(R.C_even_odd)))));
    
    
end

%Convert order of magnitude to string
pow10_str   = num2str(-log10(pow10));

if strcmp(gui_axes,'yes') == 1
    
    pow10_l_c = pow10;
    pow10_str_l_c = pow10_str;
    
end

%% Plot the results

if strcmp(gui_axes,'no') == 1
    
    %Plot only the C coefficients
    
    if order ~= deg_max
        
        figure
        set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto')
        
        if strcmp(subplots,'yes') == 1; subplot(1,2,1); end
        plot(R.x_even_odd,R.C_even_odd/pow10,'-k','Linewidth',3)
        xlabel('Degree n','fontsize',30)
        ylabel(['C_{n,' num2str(order) '} x 10^' '{' pow10_str '}'],'fontsize',30)
        set(gca,'linewidth',2,'fontsize',30)
        xlim([order deg_max])
        axis square
        grid on
        box on
        
        if order ~= deg_max - 1
            
            if strcmp(subplots,'yes') == 1; subplot(1,2,2); end
            hold on
            plot(R.x_even,R.C_even/pow10,'-b','Linewidth',3)
            plot(R.x_odd,R.C_odd/pow10,'-r','Linewidth',3)
            hold off
            xlabel('Degree n','fontsize',30)
            ylabel(['C_{n,' num2str(order) '} x 10^' '{' pow10_str '}'],'fontsize',30)
            set(gca,'linewidth',2,'fontsize',30)
            xlim([order deg_max])
            if strcmp(subplots,'yes') == 1
                legend('Even','Odd')
            else
                legend('All','Even','Odd')
            end
            axis square
            grid on
            box on
            
        end
        
    end
    
    %Plot only the S coefficients
    
    if order ~= 0 && order ~= deg_max
        
        figure
        set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto')
        
        if strcmp(subplots,'yes') == 1; subplot(1,2,1); end
        plot(R.x_even_odd,R.S_even_odd/pow10,'-k','Linewidth',3)
        xlabel('Degree n','fontsize',30)
        ylabel(['S_{n,' num2str(order) '} x 10^' '{' pow10_str '}'],'fontsize',30)
        set(gca,'linewidth',2,'fontsize',30)
        xlim([order deg_max])
        axis square
        grid on
        box on
        
        if order ~= deg_max - 1
            
            if strcmp(subplots,'yes') == 1; subplot(1,2,2); end
            hold on
            plot(R.x_even,R.S_even/pow10,'-b','Linewidth',3)
            plot(R.x_odd,R.S_odd/pow10,'-r','Linewidth',3)
            xlabel('Degree n','fontsize',30)
            ylabel(['S_{n,' num2str(order) '} x 10^' '{' pow10_str '}'],'fontsize',30)
            set(gca,'linewidth',2,'fontsize',30)
            hold off
            if strcmp(subplots,'yes') == 1
                legend('Even','Odd')
            else
                legend('All','Even','Odd')
            end
            xlim([order deg_max])
            axis square
            grid on
            box on
            
        end
        
    end
    
elseif strcmp(gui_axes,'yes') == 1 || strcmp(gui_axes,'yes_dec') == 1
        
    %Plot only the C coefficients
    if order ~= deg_max
        
        if strcmp(gui_axes,'yes') == 1
                        
            axes(handles.new_axes_1)
            
        elseif strcmp(gui_axes,'yes_dec') == 1
            
            axes(handles.new_axes_3)
            
        end
        
        plot(R.x_even_odd,R.C_even_odd/pow10_l_c,'-k','Linewidth',1)
        xlim([order deg_max])
        grid on
        set(gca,'Layer','top')
        title(['C x 10^' '{' pow10_str_l_c '}'],'FontWeight','Normal')
        
        if strcmp(gui_axes,'yes') == 1
            
            new_axes_1_lim = get(handles.new_axes_1,'Ylim');
            
        elseif strcmp(gui_axes,'yes_dec') == 1
            
            set(handles.new_axes_3,'Ylim',new_axes_1_lim)
            
        end
        
        if order ~= deg_max - 1
            
            hold on
            plot(R.x_even,R.C_even/pow10_l_c,'-b','Linewidth',1)
            plot(R.x_odd,R.C_odd/pow10_l_c,'-r','Linewidth',1)
            hold off
            legend('All','Even','Odd','Location','Best','Orientation','Vertical');
            set(legend,'EdgeColor','w')
            
        end
        
    end
    
    %Plot only the S coefficients
    if order ~= 0 && order ~= deg_max
        
        if strcmp(gui_axes,'yes') == 1
                        
            axes(handles.new_axes_2)
            
        elseif strcmp(gui_axes,'yes_dec') == 1
            
            axes(handles.new_axes_4)
            
        end
        
        plot(R.x_even_odd,R.S_even_odd/pow10_l_c,'-k','Linewidth',1)
        xlim([order deg_max])
        grid on
        set(gca,'Layer','top')
        title(['S x 10^' '{' pow10_str_l_c '}'],'FontWeight','Normal')
        
        if strcmp(gui_axes,'yes') == 1
            
            new_axes_2_lim = get(handles.new_axes_2,'Ylim');
            
        elseif strcmp(gui_axes,'yes_dec') == 1
            
            set(handles.new_axes_4,'Ylim',new_axes_2_lim)
            
        end
        
        if order ~= deg_max - 1
            
            hold on
            plot(R.x_even,R.S_even/pow10_l_c,'-b','Linewidth',1)
            plot(R.x_odd,R.S_odd/pow10_l_c,'-r','Linewidth',1)
            hold off
            legend('All','Even','Odd','Location','Best','Orientation','Vertical');
            set(legend,'EdgeColor','w')
            
        end
        
    else
        
        if strcmp(gui_axes,'yes') == 1
            
            cla(handles.new_axes_2);
            set(handles.new_axes_2,'Visible','off')
            legend(handles.new_axes_2,'off')
            
        elseif strcmp(gui_axes,'yes_dec') == 1
            
            cla(handles.new_axes_4);
            set(handles.new_axes_4,'Visible','off')
            legend(handles.new_axes_4,'off')
            
        end
        
    end
    
end

end
