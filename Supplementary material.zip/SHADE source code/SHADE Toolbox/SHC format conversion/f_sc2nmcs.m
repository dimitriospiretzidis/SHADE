function [nmcs] = f_sc2nmcs(SC,sorting)
%%
% F_SC2NMCS converts an /S|C\ matrix to a 4-element column-vector [n,m,C,S]
% matrix.
%
% HOW: [nmcs] = f_sc2nmcs(SC)
%      [nmcs] = f_sc2nmcs(SC,sorting)
%
% Input: SC          [k x 2*k-1 x p] /S|C\ matrix.
%
%        sorting                     (optional) sorting of column-vector
%                                    matrix. Options:
%                                    - 'degree' (default) coefficients are 
%                                               sorted by degree.
%                                    - 'order'  coefficients are sorted by
%                                               order.
%
% Output: nmcs [(k^2 + k)/2 x 4 x p] [n,m,C,S] matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_sc2c_s.m, f_c_s2nmcs.m

%% Revision history

%% Remarks

%% Input check
if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; sorting = 'degree'                       ; end

if size(SC,1) ~= (size(SC,2) + 1)/2
    error('<SC> should be an /S|C\ matrix.')
end

if strcmp(sorting,'degree') == 0 && strcmp(sorting,'order') == 0
    error('<sorting> should be ''degree'' or ''order''.')
end

%% Start the algorithm

%Break /S|C\ matrix into C and S components
[C,S]              = f_sc2c_s(SC);

%Create column-vector matrices from C and S components
nmcs               = f_c_s2nmcs(C,S,sorting);

end
