function [SC] = f_cs2sc(CS,mask)
%%
% F_CS2SC converts a |C\S| matrix to an /S|C\ matrix. Empty elements are
% replaced by <mask>.
%
% HOW: [SC] = f_cs2sc(CS)
%      [SC] = f_cs2sc(CS,mask)
%
% Input: CS             [n x n x k] |C\S| matrix.
%
%        mask               [1 x 1] (optional) value of empty elements.
%
% Output: SC      [n x (2*n-1) x k] /S|C\ matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_cs2c_s.m, f_c_s2sc.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; mask = NaN                               ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(mask) == 0
    error('<mask> should be a scalar.')
end

%% Start the algorithm

%Break |C\S| matrix into C and S components
[C,S]              = f_cs2c_s(CS);

%Create /S|C\ matrix from C and S components
SC                 = f_c_s2sc(C,S,mask);

end
