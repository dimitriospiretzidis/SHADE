function [nmcs] = f_c_s2nmcs(C,S,sorting)
%%
% F_C_S2NMCS converts |C\,|S\ matrices to a 4-element column-vector matrix
% [n,m,C,S].
%
% HOW: [nmcs] = f_c_s2nmcs(C,S)
%      [nmcs] = f_c_s2nmcs(C,S,sorting)
%
% Input:  C              [n x n x k] |C\ matrix.
%
%         S              [n x n x k] |S\ matrix.
%
%         sorting                    (optional) sorting of column-vector 
%                                    matrix. Options:
%                                    - 'degree' (default) coefficients are 
%                                               sorted by degree.
%                                    - 'order'  coefficients are sorted by
%                                               order.
%
% Output: nmcs [(n^2 + n)/2 x 4 x k] [n,m,C,S] matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 30/09/2017

% required m-files: f_cs2c_s.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2 && nargin ~= 3; error('Wrong number of input arguments.'); end
if nargin == 2               ; sorting = 'degree'                       ; end

if size(C,1) ~= size(C,2)
    error('<C> should be a square matrix.')
end

if size(S,1) ~= size(S,2)
    error('<S> should be a square matrix.')
end

if size(C,1) ~= size(S,1) || size(C,2) ~= size(S,2) || size(C,3) ~= size(S,3)
    error('<C> and <S> should have the same size.')
end

if strcmp(sorting,'degree') == 0 && strcmp(sorting,'order') == 0
    error('<sorting> should be ''degree'' or ''order''.')
end

%% Start the algorithm

%Maximum degree of input C and S components
deg_max            = size(C,1) - 1;

%Number of input solutions
i_max              = size(C,3);

%Create matrix with the degrees and orders
[M,N]              = meshgrid(0:deg_max,0:deg_max);

%Manipulate C and S components
[C,~]              = f_cs2c_s(C);
[S,~]              = f_cs2c_s(S);

%Manipulate N and M components
[N,~]              = f_cs2c_s(N);
[M,~]              = f_cs2c_s(M);

if strcmp(sorting,'degree') == 1
    
    C              = permute(C,[2 1 3]);
    S              = permute(S,[2 1 3]);
    N              = N';
    M              = M';
    
end

%Initialize output matrices
c                  = zeros((deg_max + 1)^2,1,i_max);
s                  = zeros((deg_max + 1)^2,1,i_max);

%Create output matrices
n                  = N(:);
m                  = M(:);

for i = 1:i_max
    
    C_temp         = C(:,:,i);
    S_temp         = S(:,:,i);
    
    c(:,1,i)       = C_temp(:);
    s(:,1,i)       = S_temp(:);
    
end

%Remove mask from output matrices
n(isnan(n) == 1)   = [];
m(isnan(m) == 1)   = [];

n                  = repmat(n,[1 1 i_max]);
m                  = repmat(m,[1 1 i_max]);

c                  = squeeze(c);
s                  = squeeze(s);

[row_c,~]          = find(isnan(c) == 1);
[row_s,~]          = find(isnan(s) == 1);

c(row_c,:)         = [];
s(row_s,:)         = [];

c                  = permute(c,[1 3 2]);
s                  = permute(s,[1 3 2]);

nmcs               = [n,m,c,s];

end
