function [CS] = f_c_s2cs(C,S)
%%
% F_C_S2CS converts |C\,|S\ matrices to a |C\S| matrix.
%
% HOW: [CS] = f_c_s2cs(C,S)
%
% Input:  C             [n x n x k] |C\ matrix.
%
%         S             [n x n x k] |S\ matrix.
%
% Output: CS            [n x n x k] |C\S| matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_cs2c_s.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2; error('Wrong number of input arguments.'); end

if size(C,1) ~= size(C,2)
    error('<C> should be a square matrix.')
end

if size(S,1) ~= size(S,2)
    error('<S> should be a square matrix.')
end

if size(C,1) ~= size(S,1)
    error('<C> and <S> should have the same size.')
end

%% Start the algorithm

%Maximum degree of input C and S components
deg_max            = size(C,1) - 1;

%Number of input solutions
i_max              = size(C,3);

%Create auxiliary variables
s_dummy            = zeros(deg_max + 1,1,i_max);

%Manipulate C and S components
C                  = f_cs2c_s(C);
C(isnan(C) == 1)   = 0;
S                  = f_cs2c_s(S);
S                  = permute([S(:,2:end,:), s_dummy],[2,1,3]);
S(isnan(S) == 1)   = 0;

%Create the |C\S| matrix
CS                 = C + S;

end
