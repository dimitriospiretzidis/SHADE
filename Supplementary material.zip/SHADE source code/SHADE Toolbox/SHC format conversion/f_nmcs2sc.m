function [SC] = f_nmcs2sc(nmcs,mask)
%%
% F_NMCS2SC converts a 4-element column-vector [n,m,C,S] matrix to a /S|C\
% matrix. Empty elements are replaced by <mask>.
%
% HOW: [SC] = f_nmcs2sc(nmcs)
%      [SC] = f_nmcs2sc(nmcs,mask)
%
% Input: nmcs       [(n^2 + n)/2 x 4 x k] [n,m,C,S] matrix.
%
%        mask                     [1 x 1] (optional) value of empty
%                                         elements.
%
% Output: SC            [n x (2*n-1) x k] /S|C\ matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_nmcs2c_s.m, f_c_s2cs.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; mask = NaN                               ; end

if min(size(nmcs,2)) ~= 4
    error('<nmcs> should be a 4-column matrix.')
end

if isscalar(mask) == 0
    error('<mask> should be a scalar.')
end

%% Start the algorithm

%Break column vectors into C and S components
[C,S]              = f_nmcs2c_s(nmcs);

%Create /S|C\ matrix from C and S components
SC                 = f_c_s2sc(C,S,mask);

end
