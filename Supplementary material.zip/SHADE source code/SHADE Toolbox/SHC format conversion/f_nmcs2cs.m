function [CS] = f_nmcs2cs(nmcs)
%%
% F_NMCS2CS converts a 4-element column-vector [n,m,C,S] matrix to a |C\S|
% matrix.
%
% HOW: [CS] = f_nmcs2cs(nmcs)
%
% Input:  nmsc  [(n^2 + n)/2 x 4 x k] [n,m,C,S] matrix.
%
% Output: CS              [n x n x k] |C\S| matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_nmcs2c_s.m, f_c_s2cs.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1; error('Wrong number of input arguments.'); end

if min(size(nmcs,2)) ~= 4
    error('<nmcs> should be a 4-column matrix.')
end

%% Start the algorithm

%Break column vectors into C and S components
[C,S]              = f_nmcs2c_s(nmcs);

%Create |C\S| matrix from C and S components
CS                 = f_c_s2cs(C,S);

end
