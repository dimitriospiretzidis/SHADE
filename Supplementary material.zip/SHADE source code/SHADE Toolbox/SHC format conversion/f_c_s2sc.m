function [SC] = f_c_s2sc(C,S,mask)
%%
% F_C_S2SC converts |C\,|S\ matrices to an /S|C\ matrix. Empty elements are
% replaced by <mask>.
%
% HOW: [SC] = f_c_s2sc(C,S)
%      [SC] = f_c_s2sc(C,S,mask)
%
% Input:  C             [n x n x k] |C\ matrix.
%
%         S             [n x n x k] |S\ matrix.
%
%        mask               [1 x 1] (optional) value of empty elements.
%
% Output: SC      [n x (2*n-1) x k] /S|C\ matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_sc2c_s.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2 && nargin ~= 3; error('Wrong number of input arguments.'); end
if nargin == 2               ; mask = NaN                               ; end

if size(C,1) ~= size(C,2)
    error('<C> should be a square matrix.')
end

if size(S,1) ~= size(S,2)
    error('<S> should be a square matrix.')
end

if size(C,1) ~= size(S,1)
    error('<C> and <S> should have the same dimensions.')
end

if isscalar(mask) == 0
    error('<mask> should be a scalar.')
end

%% Start the algorithm

%Maximum degree of input C and S components
deg_max            = size(C,1) - 1;

%Number of input solutions
i_max              = size(C,3);

%Create the initial mask in /S|C\ format
SC_NaN             = ones(deg_max + 1,2*deg_max + 1);

%Break the initial mask matrix into the C and S components
[C_NaN,S_NaN]      = f_sc2c_s(SC_NaN);

%Manipulate the mask C and S components
C_NaN(C_NaN == 0)  = NaN;
C_NaN(C_NaN == 1)  = 0;
S_NaN(S_NaN == 0)  = NaN;
S_NaN(S_NaN == 1)  = 0;

%Process every input solution
for i = 1:i_max
    
    %Apply the initial mask into the C and S component
    C(:,:,i)       = C(:,:,i) + C_NaN;
    S(:,:,i)       = S(:,:,i) + S_NaN;
    
    %Manipulate the S component
    S(:,:,i)       = fliplr(S(:,:,i));
    
end

%Create the /S|C\ matrix
SC                 = [S(:,1:end - 1,:),C];

%Apply the mask
SC(isnan(SC) == 1) = mask;

end
