function [C,S] = f_cs2c_s(CS,mask)
%%
% F_CS2C_S converts a |C\S| matrix to |C\,|S\ matrices. Empty elements are
% replaced by <mask>.
%
% HOW: [C,S] = f_cs2c_s(CS)
%      [C,S] = f_cs2c_s(CS,mask)
%
% Input: CS             [n x n x k] |C\S| matrix.
%
%        mask           [1 x 1]     (optional) value of empty elements.
%
% Output: C             [n x n x k] |C\ matrix.
%
%         S             [n x n x k] |S\ matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: none

%% Revision history

%% Remarks

%% Input check
if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; mask = NaN                               ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(mask) == 0
    error('<mask> should be a scalar.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max           = size(CS,1) - 1;

%Number of input solutions
i_max             = size(CS,3);

%Create the initial mask in |C\S| format
CS_NaN            = ones(deg_max + 1);

%Break the initial mask into the C component
C_NaN             = tril(CS_NaN,0);

%Manipulate the mask C component
C_NaN(C_NaN == 0) = NaN;
C_NaN(C_NaN == 1) = 0;

%Create auxiliary variable
s_dummy           = zeros(deg_max + 1,1);

%Initialize output C and S components
C                 = zeros(size(CS));
S                 = zeros(size(CS));

%Process every input solution
for i = 1:i_max
    
    %Break the input matrix into the C and S components
    C(:,:,i)      = tril(CS(:,:,i),0);
    S(:,:,i)      = [s_dummy, triu(CS(1:end - 1,:,i),1)'];
    
    %Apply the initial mask into the C and S component
    C(:,:,i)      = C(:,:,i) + C_NaN;
    S(:,:,i)      = S(:,:,i) + C_NaN;
    
    
end

%Apply the mask into the C and S component
C(isnan(C) == 1)  = mask;
S(isnan(S) == 1)  = mask;

end
