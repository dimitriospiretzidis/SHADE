function [CS] = f_sc2cs(SC)
%%
% F_SC2CS converts an /S|C\ matrix to a |C\S| matrix.
%
% HOW: [CS] = f_sc2cs(SC)
%
% Input: SC       [n x (2*n-1) x k] /S|C\ matrix.
%
% Output: CS            [n x n x k] |C\S| matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 30/08/2017

% required m-files: f_sc2c_s.m, f_c_s2cs.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1; error('Wrong number of input arguments.'); end

if size(SC,1) ~= (size(SC,2) + 1)/2
    error('<SC> should be an /S|C\ matrix.')
end

%% Start the algorithm

%Break /S|C\ matrix into C and S components
[C,S]              = f_sc2c_s(SC);

%Create |C\S| matrix from C and S components
CS                 = f_c_s2cs(C,S);

end
