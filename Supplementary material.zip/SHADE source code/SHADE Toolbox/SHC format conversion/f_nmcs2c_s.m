function [C,S] = f_nmcs2c_s(nmcs,mask)
%%
% F_NMCS2C_S converts a 4-element column-vector [n,m,C,S] matrix to |C\,|S\
% matrices. Empty elements are replaced by <mask>.
%
% HOW: [C,S] = f_nmcs2c_s(nmcs)
%      [C,S] = f_nmcs2c_s(nmcs,mask)
%
% Input: nmcs   [(n^2 + n)/2 x 4 x k] [n,m,C,S] matrix.
%
%        mask                 [1 x 1] (optional) value of empty elements.
%
% Output: C               [n x n x k] |C\ matrix.
%
%         S               [n x n x k] |S\ matrix.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 30/09/2017

% required m-files: f_cs2c_s.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; mask = NaN                               ; end

if min(size(nmcs,2)) ~= 4
    error('<nmcs> should be a 4-column matrix.')
end

if isscalar(mask) == 0
    error('<mask> should be a scalar.')
end

%% Start the algorithm

%Break input matrix into 4 variables
n                                  = nmcs(:,1,:);
m                                  = nmcs(:,2,:);
c                                  = nmcs(:,3,:);
s                                  = nmcs(:,4,:);

%Maximum degree of input c and s components
deg_max                            = squeeze(max(n));

if all(deg_max == deg_max(1,1)) ==1
    
    deg_max                        = deg_max(1,1);
    
else
    
    error('Input solutions do not have the same maximum degree')
    
end

%Number of input solutions
i_max                              = size(n,3);

%Initialize matrix in |C\S| format
CS                                 = zeros(deg_max + 1,deg_max + 1,i_max);

%Initialize C and S components
[C,S]                              = f_cs2c_s(CS);

%Populate C and S components
for i = 1:i_max
    
    for j = 1:size(n,1)
        
        C(n(j,1,i)+1,m(j,1,i)+1,i) = c(j,1,i);
        S(n(j,1,i)+1,m(j,1,i)+1,i) = s(j,1,i);
        
    end
    
end

%Apply the mask
C(isnan(C) == 1)                   = mask;
S(isnan(S) == 1)                   = mask;

end
