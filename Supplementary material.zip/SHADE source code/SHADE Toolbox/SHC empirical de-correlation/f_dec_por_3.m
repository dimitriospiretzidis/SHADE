function [por,C_clear,S_clear] = f_dec_por_3(CS,C_orders,S_orders)
%%
% F_DEC_POR_3 returns the portion matrix defined by the individual C and S
% orders to be de-correlated.
%
% HOW: [por]                 = f_dec_por_3(CS,C_orders,S_orders)
%      [por,C_clear,S_clear] = f_dec_por_3(CS,C_orders,S_orders)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        C_orders       [k x 1] de-correlation orders for C coefficients.
%                    or [1 x k]
%
%        S_orders       [m x 1] de-correlation orders for S coefficients.
%                    or [1 x m]
%
% Output: por           [n x n] portion matrix in |C\S| format.
%
%         C_clear      [k' x 1] processed <C_orders> after passing all 
%                               input checks.
%
%         S_clear      [m' x 1] processed <S_orders> after passing all 
%                               input checks.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 29/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Entries of <C_orders> and <S_orders> that are less than zero or exceed
%    the maximum degree and order of <CS> will be removed.
% 2) Duplicate entries of <C_orders> and <S_orders> will be removed.

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if min(size(C_orders)) > 1
    error('<C_orders> should be a vector.')
end

if min(size(S_orders)) > 1
    error('<S_orders> should be a vector.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max                      = size(CS,1) - 1;

%Force input arguments to have a column-vector format
C_orders                     = C_orders(:);
S_orders                     = S_orders(:);

%Clean the C_orders and S_orders
C_orders(C_orders < 0)       = [];
C_orders(C_orders > deg_max) = [];
S_orders(S_orders < 1)       = [];
S_orders(C_orders > deg_max) = [];

%Remove duplicate values and sort C_orders and S_orders in ascending order
C_orders                     = unique(C_orders);
S_orders                     = unique(S_orders);

%Initialize portion matrix
mask                         = zeros(deg_max + 1);

%Break initial portion matrix into C and S components
[mask_C,mask_S]              = f_cs2c_s(mask);

%Manipulate the C and S components of the portion matrix based on input
%arguments
mask_C(:,C_orders + 1)       = 1;
mask_S(:,S_orders + 1)       = 1;

%Convert portion matrix in |C\S| format from C and S components
por                          = f_c_s2cs(mask_C,mask_S);

%Pass clear input data into output variable
C_clear                      = C_orders;
S_clear                      = S_orders;

end
