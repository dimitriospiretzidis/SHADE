function [win] = f_dec_win_3(CS,por)
%%
% F_DEC_WIN_3 returns the window length matrix. The window length is equal 
% to the number of even/odd coefficients, hence, the polynomial is fitted 
% to the complete even/odd coefficient series.
%
% HOW: [win] = f_dec_win_3(CS)
%      [win] = f_dec_win_3(CS,por)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        por            [n x n] (optional) portion matrix in |C\S| format.
%
% Output: win           [n x n] window length matrix in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_cs_even_odd.m, f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Window length depends on number of coefficients.
% 2) Window length is rounded down to the nearest odd integer.
% 3) If a portion matrix is entered, the window length will be equal to the
%    even/odd coefficients inside the portion.

%% Input check

if nargin ~= 1 && nargin ~= 2; error('Wrong number of input arguments.'); end
if nargin == 1               ; por = ones(size(CS,1),size(CS,2))        ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if size(por,1) ~= size(por,2)
    error('<por> should be a |C\S| matrix.')
end

if size(CS,1) ~= size(por,1)
    error('Input arguments have different size.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max                       = size(CS,1) - 1;

%Manipulate por matrix
por(1:2,1:2)                  = 0;
por(por == 0)                 = NaN;

%Mask the coefficients according to the por matrix
CS                            = CS.*por;

%Extract the even and odd coefficient series for every order
R                             = f_cs_even_odd(CS);

%Create the initial window length matrix in |C\S| format
C_win                         = zeros(deg_max + 1);
S_win                         = zeros(deg_max + 1);

%Calculate the the window length matrix
for i = 0:deg_max
    
    %Extract the data
    C_x_even                  = R(i + 1).x_even;
    C_x_odd                   = R(i + 1).x_odd;
    S_x_even                  = R(i + 1).x_even;
    S_x_odd                   = R(i + 1).x_odd;
    C_even                    = R(i + 1).C_even;
    C_odd                     = R(i + 1).C_odd;
    S_even                    = R(i + 1).S_even;
    S_odd                     = R(i + 1).S_odd;
    
    %Keep only data inside the portion
    C_x_even(isnan(C_even))   = [];
    C_x_odd(isnan(C_odd))     = [];
    S_x_even(isnan(S_even))   = [];
    S_x_odd(isnan(S_odd))     = [];
    C_even(isnan(C_even))     = [];
    C_odd(isnan(C_odd))       = [];
    S_even(isnan(S_even))     = [];
    S_odd(isnan(S_odd))       = [];
    
    %Allocate the positions with the window length value
    C_win(C_x_even + 1,i + 1) = size(C_even,1);
    C_win(C_x_odd + 1,i + 1)  = size(C_odd,1);
    S_win(S_x_even + 1,i + 1) = size(S_even,1);
    S_win(S_x_odd + 1,i + 1)  = size(S_odd,1);
    
end

%Create the |C\S| window length matrix
win                           = f_c_s2cs(C_win,S_win);

%Round down to the nearest odd integer
win(mod(win,2) == 0)          = win(mod(win,2) == 0) - 1;

%Set minimum value of window length to 5
win                           = max(win,5);

%Mask the window length matrix according to the por matrix
por(isnan(por) == 1)          = 0;
win                           = win.*por;

end
