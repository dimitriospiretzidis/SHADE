function [win,input_clear] = f_dec_win_4(CS,order_lim,win_len)
%%
% F_DEC_WIN_4 returns the window length matrix, divided in sectors with
% respect to order, and based on <order_lim>.
%
% HOW: [win]             = f_dec_win_4(CS,order_lim,win_len)
%      [win,input_clear] = f_dec_win_4(CS,order_lim,win_len)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        order_lim      [1 x k] starting order of each polynomial degree
%                    or [k x 1] (in ascending order).
%
%        win_len        [1 x k] vector that defines the window length for 
%                    or [k x 1] each starting order.
%
% Output: win           [n x n] window length matrix in |C\S| format.
%
%         input_clear   [k x 2] processed input arguments
%                               [order_lim_clear,win_len_clear] after
%                               passing all input checks.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 29/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Window length depends only on order m.
% 2) Entries with <win_len> = 0 will be removed. The window length matrix
%    will be calculated using the remaining entries.
% 3) If <order_lim> is not sorted in ascending order, <order_lim> and
%    <win_len> will be sorted in ascending order with respect to
%    <order_lim>.
% 4) If order_lim(1,1) ~= 0, the window length from order 0 to
%    order_lim(1,1) will be equal to win_len(1,1).
% 5) If order_lim(end,1) ~= deg_max, the polynomial degree from order
%    order_lim(end,1) to deg_max will be equal to win_len(end,1).

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if min(size(order_lim)) ~= 1
    error('<order_lim> should be a vector.')
end

if min(size(win_len)) ~= 1
    error('<win_len> should be a vector.')
end

%Force input arguments to have a column-vector format
order_lim                                        = order_lim(:);
win_len                                          = win_len(:);

if size(order_lim,1) ~= size(win_len,1)
    error('<order_lim> and <win_len> should have the same dimensions.')
end

if max(isnan([order_lim;win_len])) == 1
    error('Input arguments contain NaNs.')
end

%Remove entries with win_len = 0
order_lim(win_len == 0)                          = [];
win_len(win_len == 0)                            = [];

%Check for duplicate values in order_lim
if size(order_lim,1) ~= size(unique(order_lim),1)
    error('<order_lim> contains duplicate values.')
end

if issorted(order_lim) ~= 1
    warning('<order_lim> is not sorted in ascending order. Sorting of <order_lim> and <win_len> in ascending order will be performed, with respect to <order_lim>.')
    
    %Sort order_lim and win_len in ascending order with respect to
    %order_lim
    data_temp                                    = sortrows([order_lim,win_len]);
    order_lim                                    = data_temp(:,1);
    win_len                                      = data_temp(:,2);
    
end

%Maximum degree of input CS matrix
deg_max                                          = size(CS,1) - 1;

if max(order_lim) > deg_max
    error('<order_lim> value exceeds maximum degree of expansion.')
end

%% Start the algorithm

%Initialize C component of the polynomial degree matrix and populate the
%first section of C_win
C_win                                            = win_len(1,1)*ones(deg_max + 1);

%Populate C_pol
for i = 1:size(order_lim,1)-1
    
    C_win(:,order_lim(i,1) + 1:order_lim(i+1,1)) = win_len(i,1);
    
end

%Populate the last section of C_pol
C_win(:,order_lim(end,1) + 1:end)                = win_len(end,1);

%Create the polynomial degree matrix in |C\S| format.
win                                              = f_c_s2cs(C_win,C_win);

%Pass clear input data into output variable
input_clear                                      = [order_lim,win_len];

end
