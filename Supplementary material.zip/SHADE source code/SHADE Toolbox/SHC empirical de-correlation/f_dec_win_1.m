function [win] = f_dec_win_1(CS,A,K)
%%
% F_DEC_WIN_1 returns the order-dependent window length matrix given by
% Eq.(1) in:
%
% Duan et al. (2009), On the postprocessing removal of correlated errors in
%      GRACE temporal gravity field solutions, J. Geod., 83:1095�1106,
%      doi:10.1007/s00190-009-0327-0.
%
% HOW: [win] = f_dec_win_1(CS,A,K)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        A              [1 x 1] window length parameter.
%
%        K              [1 x 1] window length parameter.
%
% Output: win           [n x n] window length matrix in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 06/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Window length depends only on order m.
% 2) Window length is rounded down to the nearest odd integer.
% 3) Minimum window length is 5.

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(A) == 0 || isscalar(K) == 0
    error('Window length parameters should be scalars.')
end

if isnan(A) == 1 || isnan(K) == 1
    error('Window length parameters containg NaN or non-numeric values.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max              = size(CS,1) - 1;

%Create order matrix
[m,~]                = meshgrid(0:deg_max,0:deg_max);

%Calculate the window length matrix
win                  = floor(A*exp(-m/K) + 1);

%Round down to the nearest odd integer
win(mod(win,2) == 0) = win(mod(win,2) == 0) - 1;

%Set minimum value of window length to 5
win                  = max(win,5);

%Create auxiliary variable
s_dummy              = zeros(deg_max + 1,1);

%Calculate the C and S components of the window
w_C                  = tril(win);
w_S                  = [s_dummy, w_C(:,2:end)];

%Convert window to |C\S| format
win                  = f_c_s2cs(w_C,w_S);

end
