function [por] = f_dec_por_2(CS,r,n1,m1,n2,m2)
%%
% F_DEC_POR_2 returns the portion matrix defined by a boundary curve. For
% more details see:
%
% Duan et al. (2009), On the postprocessing removal of correlated errors in
%      GRACE temporal gravity field solutions, J. Geod., 83:1095�1106,
%      doi:10.1007/s00190-009-0327-0.
%
% HOW: [por] = f_dec_por_2(CS,r,n1,m1,n2,m2)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        r              [1 x 1] curvature parameter.
%
%        n1             [1 x 1] degree of curve starting point.
%
%        m1             [1 x 1] order of curve starting point.
%
%        n2             [1 x 1] degree of curve ending point.
%
%        m2             [1 x 1] order of curve ending point.
%
% Output: por           [n x n] portion matrix in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 27/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 6; error('Wrong number of input arguments.') ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(r) == 0 || isscalar(n1) == 0 || isscalar(m1) == 0 || isscalar(n2) == 0 || isscalar(m2) == 0
    error('Portion parameters should be scalars.')
end

if isnan(r) == 1 || isnan(n1) == 1 || isnan(m1) == 1 || isnan(n2) == 1 || isnan(m2) == 1
    error('Portion parameters containg NaN or non-numeric values.')
end

if r < 0 || n1 < 0 || m1 < 0 || n2 < 0 || m2 < 0
    error('Portion parameters should be non-negative.')
end

%Maximum degree of input CS matrix
deg_max = size(CS,1) - 1;

if n1 > deg_max || m1 > deg_max || n2 > deg_max || m2 > deg_max
    error('Portion parameters exceed maximum degree of <CS>.')
end

%% Start the algorithm

%Create degree and order matrices
[m,n]   = meshgrid(0:deg_max,0:deg_max);
n       = tril(n);
m       = tril(m);

%Calculate parameters a and b
a       = n1;
b       = (n2 - n1)/(m2^r);

%Create auxiliary variable
s_dummy = zeros(deg_max + 1,1);

%Calculate the C and S components of the mask
mask_C  = (a + b.*m.^r) <= n;
mask_S  = [s_dummy, mask_C(:,2:end)];

%Convert mask to |C\S| format
por     = f_c_s2cs(mask_C,mask_S);

end
