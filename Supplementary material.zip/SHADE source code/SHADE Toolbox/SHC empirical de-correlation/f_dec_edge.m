function [CS_edge_1,CS_edge_2] = f_dec_edge(CS,por,win,por_flag)
%%
% F_DEC_EDGE returns the part of a coefficient matrix where class-1 and
% class-2 edge effects appear. Coefficients with edge effects are noted
% with 1.
%
% HOW: [CS_edge_1,CS_edge_2] = f_dec_edge(CS,por,win,por)
%      [CS_edge_1,CS_edge_2] = f_dec_edge(CS,por,win,por_flag)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        por            [n x n] de-correlation portion in |C\S| format,
%                               denoted by 1. The portion left unchanged is
%                               denoted by 0. See f_dec_por_1.m,
%                               f_dec_por_2.m and f_dec_por_3.m for more
%                               information.
%
%        win            [n x n] window length in |C\S| format. See
%                    or [1 x 1] f_dec_win_1.m, f_dec_win_2.m, f_dec_win_3.m
%                               and f_dec_win_4.m for more information.
%
%        por_flag       [1 x 1] (optional) boolean that controls which
%                               coefficients are used for the polynomial
%                               fitting. Options:
%                               - 0 (default) all coefficients are used.
%                               - 1 only coefficients inside the
%                                   de-correlation portion are used.
%
% Output: CS_edge_1     [n x n] coefficients with class-1 edge effects in
%                               |C\S| format.
%
%         CS_edge_2     [n x n] coefficients with class-2 edge effects in
%                               |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 10/12/2017

% required m-files: f_cs2c_s.m, f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Only odd values for window length are allowed.
% 2) Coefficients C00, C10, C11 and S11 are not taken into account in the
%    polynomial fit.
% 3) Edge effects do not depend on the polynomial degree.

%% Input check

if nargin ~= 3 && nargin ~= 4; error('Wrong number of input arguments.'); end
if nargin == 3               ; por_flag = 1                             ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if size(win,1) ~= size(win,2)
    error('<win> should be a scalar or a |C\S| matrix.')
end

if size(por,1) ~= size(por,2)
    error('<por> should be a |C\S| matrix.')
end

if por_flag ~=0 && por_flag ~= 1
    error('<por_flag> should be either 0 or 1.')
end

%% Start the algorithm

%Set all warning messages off
warning('off','all')

%Maximum degree of input CS matrix
deg_max                             = size(CS,1) - 1;

%Check if window length is scalar
if isscalar(win) == 1; win = win*ones(deg_max + 1); end

%Check if window length is even
if min(min(mod(win(por == 1),2))) == 0
    error('<win> should only contain odd values.')
end

%Initialize matrices containing the coefficients with edge effects
CS_edge_1                           = zeros(deg_max + 1);
CS_edge_2                           = zeros(deg_max + 1);

%Break input matrices into C and S components
[C_edge_1,S_edge_1]                 = f_cs2c_s(CS_edge_1);
[C_edge_2,S_edge_2]                 = f_cs2c_s(CS_edge_2);
[C_win,S_win]                       = f_cs2c_s(win);
[C_por,S_por]                       = f_cs2c_s(por);

%Find the minimum and maximum degree for each order according to por and
%por_flag
if por_flag == 0
    
    C_deg_min                       = [2,2,2:deg_max];
    S_deg_min                       = [2,2,2:deg_max];
    C_deg_max                       = deg_max*ones(deg_max + 1,1);
    S_deg_max                       = deg_max*ones(deg_max + 1,1);
    
else
    
    C_por(1:2,1:2)                  = 0;
    S_por(1:2,1:2)                  = 0;
    
    [C_deg_min,...
     S_deg_min,...
     C_deg_max,...
     S_deg_max]                     = f_find_lim(C_por,S_por);
    
end

%Calculate de-correlation filter
for m = 0:deg_max
    
    for n = m:deg_max
        
        %Get the window for degree n and order m
        w_C                         = C_win(n+1,m+1);
        w_S                         = S_win(n+1,m+1);
        
        %Get minimum and maximum degrees
        n_min_C                     = C_deg_min(m+1);
        n_max_C                     = C_deg_max(m+1);
        n_min_S                     = S_deg_min(m+1);
        n_max_S                     = S_deg_max(m+1);
        
        %Check the Cnm coefficients
        if n-(w_C-1) < n_min_C
            
            %Get the window of near-sectoral coefficients by taking into
            %account edge effects
            if mod(n_min_C,2) == mod(n,2)
                
                x_data_C            = (n_min_C:2:n_min_C+(w_C-1)*2);
                
            else
                
                x_data_C            = (n_min_C+1:2:n_min_C+1+(w_C-1)*2);
                
            end
            
        elseif (n-(w_C-1) >= n_min_C) && (n+(w_C-1) <= n_max_C)
            
            %Get the window of coefficients without edge effects
            x_data_C                = (n-(w_C-1):2:n+(w_C-1));
            
        elseif n+(w_C-1) > n_max_C
            
            %Get the window of near-maximum degree coefficients by taking
            %into account edge effects
            if mod(n_max_C,2) == mod(n,2)
                
                x_data_C            = (n_max_C-(w_C-1)*2:2:n_max_C);
                
            else
                
                x_data_C            = (n_max_C-1-(w_C-1)*2:2:n_max_C-1);
                
            end
            
        end
        
        %Check the Snm coefficients
        if n-(w_S-1) < n_min_S
            
            %Get the window of near-sectoral coefficients by taking into
            %account edge effects
            if mod(n_min_S,2) == mod(n,2)
                
                x_data_S            = (n_min_S:2:n_min_S+(w_S-1)*2);
                
            else
                
                x_data_S            = (n_min_S+1:2:n_min_S+1+(w_S-1)*2);
                
            end
            
        elseif (n-(w_S-1) >= n_min_S) && (n+(w_S-1) <= n_max_S)
            
            %Get the window of coefficients without edge effects
            x_data_S                = (n-(w_S-1):2:n+(w_S-1));
            
        elseif n+(w_S-1) > n_max_S
            
            %Get the window of near-maximum degree coefficients by taking
            %into account edge effects
            if mod(n_max_S,2) == mod(n,2)
                
                x_data_S            = (n_max_S-(w_S-1)*2:2:n_max_S);
                
            else
                
                x_data_S            = (n_max_S-1-(w_S-1)*2:2:n_max_S-1);
                
            end
            
        end
        
        if min(x_data_C) >= n_min_C & min(x_data_C) <= n & max(x_data_C) <= n_max_C & max(x_data_C) >= n
            
            %Check for class-2 edge effects
            if x_data_C((w_C+1)/2) ~= n
                
                C_edge_2(n+1,m+1)   = 1;
                
            end
            
        else
            
            %Check for class-1 edge effects
            C_edge_1(n+1,m+1)       = 1;
            
        end
        
        if min(x_data_S) >= n_min_S & min(x_data_S) <= n & max(x_data_S) <= n_max_S & max(x_data_S) >= n
            
            %Check for class-2 edge effects
            if x_data_S((w_S+1)/2) ~= n
                
                S_edge_2(n+1,m+1)   = 1;
                
            end
            
        else
            
            %Check for class-1 edge effects
            S_edge_1(n+1,m+1)       = 1;
            
        end
        
    end
    
end

%Create the |C\S| matrix with coefficients with edge effects
CS_edge_1                           = f_c_s2cs(C_edge_1,S_edge_1);
CS_edge_2                           = f_c_s2cs(C_edge_2,S_edge_2);

%Set all warning messages on again
warning('on','all')

%Nested function f_find_lim for finding the minimum and maximum degree for
%the polynomial fitting in every order.
    function [C_deg_min,S_deg_min,C_deg_max,S_deg_max] = f_find_lim(C_por,S_por)
        
        %Manipulate por matrix
        C_por(C_por == 0)           = NaN;
        S_por(S_por == 0)           = NaN;
        
        %Create the degree matrix in |C\S| format.
        CS_deg                      = meshgrid(0:deg_max)';
        
        %Break degree matrix into C and S components
        [C_deg,~]                   = f_cs2c_s(CS_deg,NaN);
        [S_deg,~]                   = f_cs2c_s(CS_deg,NaN);
        
        %Mask degree matrices
        C_deg                       = C_deg.*C_por;
        S_deg                       = S_deg.*S_por;
        
        %Find minimum and maximum degrees
        C_deg_min                   = min(C_deg);
        C_deg_max                   = max(C_deg);
        S_deg_min                   = min(S_deg);
        S_deg_max                   = max(S_deg);
        
        %Manipulate minimum and maximum degrees
        C_deg_min(isnan(C_deg_min)) = 0;
        C_deg_max(isnan(C_deg_max)) = 0;
        S_deg_min(isnan(S_deg_min)) = 0;
        S_deg_max(isnan(S_deg_max)) = 0;
        
    end

end
