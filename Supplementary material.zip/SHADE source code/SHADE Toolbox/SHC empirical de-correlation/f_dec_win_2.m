function [win] = f_dec_win_2(CS,A,K,gamma,pe)
%%
% F_DEC_WIN_2 returns the degree- and order-dependent window length matrix
% given by Eq.(3) in:
%
% Duan et al. (2009), On the postprocessing removal of correlated errors in
%      GRACE temporal gravity field solutions, J. Geod., 83:1095�1106,
%      doi:10.1007/s00190-009-0327-0.
%
% HOW: [win] = f_dec_win_2(CS,A,K,gamma,pe,round)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        A              [1 x 1] window length parameter.
%
%        K              [1 x 1] window length parameter.
%
%        gamma          [1 x 1] window length parameter.
%
%        pe             [1 x 1] window length parameter.
%
% Output: win           [n x n] window length matrix in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 06/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Window length depends on both degree n and order m.
% 2) Window length is rounded down to the nearest odd integer.
% 3) Minimum window length is 5.

%% Input check

if nargin ~= 5; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isscalar(A) == 0 || isscalar(K) == 0 || isscalar(gamma) == 0 || isscalar(pe) == 0
    error('Window length parameters should be scalars.')
end

if isnan(A) == 1 || isnan(K) == 1 || isnan(gamma) == 1 || isnan(pe) == 1
    error('Window length parameters containg NaN or non-numeric values.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max              = size(CS,1) - 1;

%Create order matrix
[m,n]                = meshgrid(0:deg_max,0:deg_max);

%Calculate the window length matrix
win                  = floor(A*exp(-(((1 - gamma)*(m.^pe) + gamma*(n.^pe)).^(1/pe))/K) + 1);

%Round down to the nearest odd integer
win(mod(win,2) == 0) = win(mod(win,2) == 0) - 1;

%Set minimum value of window length to 5
win                  = max(win,5);

%Create auxiliary variable
s_dummy              = zeros(deg_max + 1,1);

%Calculate the C and S components of the window
w_C                  = tril(win);
w_S                  = [s_dummy, w_C(:,2:end)];

%Convert window to |C\S| format
win                  = f_c_s2cs(w_C,w_S);

end
