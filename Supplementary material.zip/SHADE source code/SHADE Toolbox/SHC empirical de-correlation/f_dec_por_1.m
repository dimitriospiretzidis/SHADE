function [por] = f_dec_por_1(CS,start_degree,end_degree,start_order,end_order)
%%
% F_DEC_POR_1 returns the portion matrix defined by a minimum and maximum
% degree and order.
%
% HOW: [por] = f_dec_por_1(CS,start_order,end_order,start_degree,end_degree)
%
% Input: CS              [n x n] coefficients in |C\S| format.
%
%        start_degree    [1 x 1] starting degree of the matrix portion. If 
%                     or   'min' 'min', the decorrelation starts from
%                                degree 0.
%
%        end_degree      [1 x 1] ending degree of the matrix portion. If 
%                     or   'max' 'max', the decorrelation ends at maximum
%                                 degree of CS.
%
%        start_order     [1 x 1] starting order of the matrix portion. If 
%                     or   'min' 'min', the decorrelation starts from order
%                                0.
%
%        end_order       [1 x 1] ending order of the matrix portion. If
%                     or   'max' 'max', the decorrelation ends at maximum
%                                order of CS.
%
% Output: por            [n x n] portion matrix in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 05/09/2017

% required m-files: f_cs2sc.m, f_sc2cs.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 5; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

%Maximum degree of input CS matrix
deg_max = size(CS,1) - 1;

%Check if input is a string
if strcmp(start_degree,'min') == 1; start_degree = 0       ; end
if strcmp(end_degree,'max')   == 1; end_degree   = deg_max ; end
if strcmp(start_order,'min')  == 1; start_order  = 0       ; end
if strcmp(end_order,'max')    == 1; end_order    = deg_max ; end

if end_degree < start_degree
    error('<end_degree> cannot be less than <start_degree>.');
end

if end_order < start_order
    error('<end_order> cannot be less than <start_order>.');
end

if end_degree < start_order
    error('<end_degree> cannot be smaller than <start_order>. There is no overlapping between degree and order limits.')
end

if isscalar(start_degree) == 0 || isscalar(end_degree) == 0 || isscalar(start_order) == 0 || isscalar(end_order) == 0
    error('Portion parameters should be scalars.')
end

if isnan(start_degree) == 1 || isnan(end_degree) == 1 || isnan(start_order) == 1 || isnan(end_order) == 1
    error('Portion parameters contain NaN or non-numeric values.')
end

if start_degree < 0 || end_degree < 0 || start_order < 0 || end_order < 0
    error('Portion parameters should be non-negative.')
end

if start_degree > deg_max || end_degree > deg_max || start_order > deg_max || end_order > deg_max
    error('Portion parameters exceed maximum degree of CS.')
end

%% Start the algorithm

%Convert input matrix into /S|C\ format
SC      = f_cs2sc(CS);

%Initialize the portion matrix
mask    = zeros(size(SC,1),size(SC,2));

%Create the portion matrix according to to minimum and maximum degree and 
%order
mask(start_degree+1:end_degree+1,deg_max+1+start_order:deg_max+1+end_order)...
        = 1;

mask(start_degree+1:end_degree+1,deg_max+1-end_order:deg_max+1-start_order)...
        = 1;

%Convert portion matrix into |C\S| format
por     = f_sc2cs(mask);

end
