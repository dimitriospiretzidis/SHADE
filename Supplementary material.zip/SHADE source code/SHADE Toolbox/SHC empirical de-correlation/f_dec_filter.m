function [CS_f] = f_dec_filter(CS,sigma_CS,por,win,pol,por_flag)
%%
% F_DEC_FILTER performs empirical de-correlation of spherical harmonic
% coefficients using a polynomial fit to even/odd degrees. The polynomial
% fit is performed within a moving window of degrees for every order. For
% more details see:
%
% Swenson, S., and J. Wahr (2006), Post-processing removal of correlated
%      errors in GRACE data, Geophys. Res. Lett., 33, L08402,
%      doi:10.1029/2005GL025285.
%
% Duan et al. (2009), On the postprocessing removal of correlated errors in
%      GRACE temporal gravity field solutions, J. Geod., 83:1095�1106,
%      doi:10.1007/s00190-009-0327-0.
%
% HOW: [CS_f] = f_dec_filter(CS,sigma_CS,por,win,pol)
%      [CS_f] = f_dec_filter(CS,sigma_CS,por,win,pol,por_flag)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        sigma_CS       [n x n] standard deviations of coefficients in
%                    or     NaN |C\S| format. If standard deviations are
%                    or      [] not known or given, use sigma_CS = NaN or
%                               sigma_CS = [].
%
%        por            [n x n] de-correlation portion in |C\S| format,
%                               denoted by 1. The portion left unchanged is
%                               denoted by 0. See f_dec_por_1.m,
%                               f_dec_por_2.m and f_dec_por_3.m for more
%                               information.
%
%        win            [n x n] window length in |C\S| format. See
%                    or [1 x 1] f_dec_win_1.m, f_dec_win_2.m, f_dec_win_3.m
%                               and f_dec_win_4.m for more information.
%
%        pol            [n x n] polynomial degree in |C\S| format. See 
%                    or [1 x 1] f_dec_pol.m for more information.
%
%        por_flag       [1 x 1] (optional) boolean that controls which
%                               coefficients are used for the polynomial
%                               fitting. Options:
%                               - 0 (default) all coefficients are used.
%                               - 1 only coefficients inside the
%                                   de-correlation portion are used.
%
% Output: CS_f          [n x n] de-correlated coefficients in |C\S| format.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 23/01/2015

% required m-files: f_cs2c_s.m, f_c_s2cs.m

%% Revision history

% 29/09/2017 : Dimitrios Piretzidis
%              De-correlation can start from order 0. Input
%              arguments generalized. Computations accelerated ~10 times by
%              replacing polyfit with f_polyfit. Standard deviations are
%              added.

%% Remarks

% 1) Only odd values for window length are allowed.
% 2) Coefficients C00, C10, C11 and S11 are not taken into account in the
%    polynomial fit.

%% Input check

if nargin < 5 || nargin > 6; error('Wrong number of input arguments.'); end
if nargin == 5             ; por_flag  = 0                            ; end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if isempty(sigma_CS) == 1
    sigma_CS = NaN;
end

if size(sigma_CS,1) ~= size(sigma_CS,2)
    error('<sigma_CS> should be a |C\S| matrix or a NaN scalar.')
end

if size(sigma_CS,1) ~= size(CS,2) && isnan(sigma_CS) ~= 1
    error('<sigma_CS> should be a |C\S| matrix, NaN scalar or [].')
end

if size(pol,1) ~= size(pol,2)
    error('<pol> should be a scalar or a |C\S| matrix.')
end

if size(win,1) ~= size(win,2)
    error('<win> should be a scalar or a |C\S| matrix.')
end

if size(por,1) ~= size(por,2)
    error('<por> should be a |C\S| matrix.')
end

if por_flag ~= 0 && por_flag ~= 1
    error('<por_flag> should be either 0 or 1.')
end

%% Start the algorithm

%Maximum degree of input CS matrix
deg_max                             = size(CS,1) - 1;

%Check if polynomial degree and window length are scalars
if isscalar(pol) == 1; pol = pol*ones(deg_max + 1); end
if isscalar(win) == 1; win = win*ones(deg_max + 1); end

%Check if window length is even
if min(min(mod(win(por == 1),2))) == 0
    error('<win> should only contain odd values.')
end

%Check if polynomial degree is greater than window length
check_fit                           = zeros(size(por));
check_fit(por == 1)                 = +(win(por == 1) < (pol(por == 1) + 1));

if max(check_fit(:)) == 1
    warning('<win> cannot be less than (<pol> + 1). Some coefficients are ignored.')
    por(check_fit == 1)             = 0;
end

%Replace any zero entries in sigma_CS with the smallest standard deviation
if isnan(sigma_CS) == 0
    
    sigma_CS(sigma_CS == 0)         = min(sigma_CS(:));
    
end

%Initialize C and S components of matrix containing the polynomial
%contribution
poly_con_C                          = zeros(deg_max + 1);
poly_con_S                          = zeros(deg_max + 1);

%Break input matrices into C and S components
[C,S]                               = f_cs2c_s(CS);

if isnan(sigma_CS) == 0
    
    [sigma_C,sigma_S]               = f_cs2c_s(sigma_CS);
    
end

[C_pol,S_pol]                       = f_cs2c_s(pol);
[C_win,S_win]                       = f_cs2c_s(win);
[C_por,S_por]                       = f_cs2c_s(por);

%Find the minimum and maximum degree for each order according to por and
%por_flag
if por_flag == 0
    
    C_deg_min                       = [2,2,2:deg_max];
    S_deg_min                       = [2,2,2:deg_max];
    C_deg_max                       = deg_max*ones(deg_max + 1,1);
    S_deg_max                       = deg_max*ones(deg_max + 1,1);
    
else
    
    C_por(1:2,1:2)                  = 0;
    S_por(1:2,1:2)                  = 0;
    
    [C_deg_min,...
     S_deg_min,...
     C_deg_max,...
     S_deg_max]                     = f_find_lim(C_por,S_por);
    
end

%Set all warning messages off
warning('off','all')

%Calculate de-correlation filter
for m = 0:deg_max
    
    for n = m:deg_max
        
        %Get the window for degree n and order m
        w_C                         = C_win(n+1,m+1);
        w_S                         = S_win(n+1,m+1);
        
        %Get minimum and maximum degrees
        n_min_C                     = C_deg_min(m+1);
        n_max_C                     = C_deg_max(m+1);
        n_min_S                     = S_deg_min(m+1);
        n_max_S                     = S_deg_max(m+1);
        
        %Check the Cnm coefficients
        if n-(w_C-1) < n_min_C
            
            %Get the window of near-sectoral coefficients by taking into
            %account edge effects
            if mod(n_min_C,2) == mod(n,2)
                
                x_data_C            = (n_min_C:2:n_min_C+(w_C-1)*2);
                
            else
                
                x_data_C            = (n_min_C+1:2:n_min_C+1+(w_C-1)*2);
                
            end
            
        elseif (n-(w_C-1) >= n_min_C) && (n+(w_C-1) <= n_max_C)
            
            %Get the window of coefficients without edge effects
            x_data_C                = (n-(w_C-1):2:n+(w_C-1));
            
        elseif n+(w_C-1) > n_max_C
            
            %Get the window of near-maximum degree coefficients by taking
            %into account edge effects
            if mod(n_max_C,2) == mod(n,2)
                
                x_data_C            = (n_max_C-(w_C-1)*2:2:n_max_C);
                
            else
                
                x_data_C            = (n_max_C-1-(w_C-1)*2:2:n_max_C-1);
                
            end
            
        end
        
        %Check the Snm coefficients
        if n-(w_S-1) < n_min_S
            
            %Get the window of near-sectoral coefficients by taking into
            %account edge effects
            if mod(n_min_S,2) == mod(n,2)
                
                x_data_S            = (n_min_S:2:n_min_S+(w_S-1)*2);
                
            else
                
                x_data_S            = (n_min_S+1:2:n_min_S+1+(w_S-1)*2);
                
            end
            
        elseif (n-(w_S-1) >= n_min_S) && (n+(w_S-1) <= n_max_S)
            
            %Get the window of coefficients without edge effects
            x_data_S                = (n-(w_S-1):2:n+(w_S-1));
            
        elseif n+(w_S-1) > n_max_S
            
            %Get the window of near-maximum degree coefficients by taking
            %into account edge effects
            if mod(n_max_S,2) == mod(n,2)
                
                x_data_S            = (n_max_S-(w_S-1)*2:2:n_max_S);
                
            else
                
                x_data_S            = (n_max_S-1-(w_S-1)*2:2:n_max_S-1);
                
            end
            
        end
        
        %Calculate polynomial contribution for Cnm coefficients
        if min(x_data_C) >= n_min_C & min(x_data_C) <= n & max(x_data_C) <= n_max_C & max(x_data_C) >= n
            
            cs_data                 = C(x_data_C+1,m+1)';
            
            if isnan(sigma_CS) == 0
                
                sigma_cs_data       = sigma_C(x_data_C+1,m+1)';
                poly_1              = f_wpolyfit(x_data_C - mean(x_data_C),sigma_cs_data,cs_data,C_pol(n+1,m+1));
                poly_con_C(n+1,m+1) = polyval(poly_1,n - mean(x_data_C));
                
            elseif isnan(sigma_CS) == 1
                
                poly_1              = f_polyfit(x_data_C - mean(x_data_C),cs_data,C_pol(n+1,m+1));
                poly_con_C(n+1,m+1) = polyval(poly_1,n - mean(x_data_C));
                
            end
            
        end
        
        %Calculate polynomial contribution for Snm coefficients
        if min(x_data_S) >= n_min_S & min(x_data_S) <= n & max(x_data_S) <= n_max_S & max(x_data_S) >= n
            
            cs_data                 = S(x_data_S+1,m+1)';
            
            if isnan(sigma_CS) == 0
                
                sigma_cs_data       = sigma_S(x_data_S+1,m+1)';
                poly_1              = f_wpolyfit(x_data_S - mean(x_data_S),sigma_cs_data,cs_data,S_pol(n+1,m+1));
                poly_con_S(n+1,m+1) = polyval(poly_1,n - mean(x_data_S));
                
            elseif isnan(sigma_CS) == 1
                
                poly_1              = f_polyfit(x_data_S - mean(x_data_S),cs_data,S_pol(n+1,m+1));
                poly_con_S(n+1,m+1) = polyval(poly_1,n - mean(x_data_S));
                
            end
            
        end
        
    end
    
end

%Create the |C\S| matrix with the polynomial contribution
poly_con                            = f_c_s2cs(poly_con_C,poly_con_S);

%Correct the C00 coefficient, in case de-correlation starts from order 0
if CS(1,1) == 0
    
    poly_con(1,1)                   = 0;
    
end

%Remove the polynomial contribution from the input matrix
CS_f                                = CS - poly_con.*por;

%Set all warning messages on again
warning('on','all')

%Nested function f_polyfit (faster version of MATLAB's polyfit using
%ordinary least-squares adjustment)
    function p = f_polyfit(x,y,n)
        
        x                           = x(:);
        y                           = y(:);
        
        %Design matrix
        A                           = repmat(x,1,n+1);
        A                           = bsxfun(@power,A,n:-1:0);
        
        %Ordinary least-squares adjustment
        p                           = A\y;
        p                           = p';
        
    end

%Nested function f_wpolyfit (version of MATLAB's polyfit using weighted
%least-squares adjustment)
    function p = f_wpolyfit(x,sigma_x,y,n)
        
        x                           = x(:);
        sigma_x                     = sigma_x(:);
        y                           = y(:);
        
        %Signal covariance matrix
        C_x                         = diag(sigma_x.^2);
        
        %Weight matrix
        P                           = C_x^(-1);
        
        %Design matrix
        A                           = repmat(x,1,n+1);
        A                           = bsxfun(@power,A,n:-1:0);
        
        %Weighted least-squares adjustment
        p                           = (A'*P*A)\(A'*P*y);
        p                           = p';
        
    end

%Nested function f_find_lim for finding the minimum and maximum degree for
%the polynomial fitting in every order.
    function [C_deg_min,S_deg_min,C_deg_max,S_deg_max] = f_find_lim(C_por,S_por)
        
        %Manipulate por matrix
        C_por(C_por == 0)           = NaN;
        S_por(S_por == 0)           = NaN;
        
        %Create the degree matrix in |C\S| format.
        CS_deg                      = meshgrid(0:deg_max)';
        
        %Break degree matrix into C and S components
        [C_deg,~]                   = f_cs2c_s(CS_deg,NaN);
        [S_deg,~]                   = f_cs2c_s(CS_deg,NaN);
        
        %Mask degree matrices
        C_deg                       = C_deg.*C_por;
        S_deg                       = S_deg.*S_por;
        
        %Find minimum and maximum degrees
        C_deg_min                   = min(C_deg);
        C_deg_max                   = max(C_deg);
        S_deg_min                   = min(S_deg);
        S_deg_max                   = max(S_deg);
        
        %Manipulate minimum and maximum degrees
        C_deg_min(isnan(C_deg_min)) = 0;
        C_deg_max(isnan(C_deg_max)) = 0;
        S_deg_min(isnan(S_deg_min)) = 0;
        S_deg_max(isnan(S_deg_max)) = 0;
        
    end

end
