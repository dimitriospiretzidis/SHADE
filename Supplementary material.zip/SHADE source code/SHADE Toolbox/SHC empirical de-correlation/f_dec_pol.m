function [pol,input_clear] = f_dec_pol(CS,order_lim,pol_deg)
%%
% F_DEC_POL returns the polynomial degree matrix, divided in sectors with
% respect to order and based on <order_lim>.
%
% HOW: [pol]             = f_dec_pol(CS,order_lim,pol_deg)
%      [pol,input_clear] = f_dec_pol(CS,order_lim,pol_deg)
%
% Input: CS             [n x n] coefficients in |C\S| format.
%
%        order_lim      [1 x k] starting order of each polynomial degree
%                    or [k x 1] (in ascending order).
%
%        pol_deg        [1 x k] polynomial degree for each starting order.
%                    or [k x 1]
%
% Output: pol           [n x n] polynomial degree matrix in |C\S| format.
%
%         input_clear   [k x 2] processed input arguments
%                               [order_lim_clear,pol_deg_clear] after
%                               passing all input checks.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 29/09/2017

% required m-files: f_c_s2cs.m

%% Revision history

%% Remarks

% 1) Polynomial degree depends only on order m.
% 2) Entries with <pol_deg> = 0 will be removed. The polynomial degree
%    matrix will be calculated using the remaining entries.
% 3) If <order_lim> is not sorted in ascending order, <order_lim> and
%    <pol_deg> will be sorted in ascending order with respect to
%    <order_lim>.
% 4) If order_lim(1,1) ~= 0, the polynomial degree from order 0 to
%    order_lim(1,1) will be equal to pol_deg(1,1).
% 5) If order_lim(end,1) ~= deg_max, the polynomial degree from order
%    order_lim(end,1) to deg_max will be equal to pol_deg(end,1).

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if size(CS,1) ~= size(CS,2)
    error('<CS> should be a |C\S| matrix.')
end

if min(size(order_lim)) ~= 1
    error('<order_lim> should be a vector.')
end

if min(size(pol_deg)) ~= 1
    error('<pol_deg> should be a vector.')
end

%Force input arguments to have a column-vector format
order_lim                                        = order_lim(:);
pol_deg                                          = pol_deg(:);

if size(order_lim,1) ~= size(pol_deg,1)
    error('<order_lim> and <pol_deg> should have the same dimensions.')
end

if max(isnan([order_lim;pol_deg])) == 1
    error('Input arguments contain NaNs.')
end

%Remove entries with pol_deg = 0
order_lim(pol_deg == 0)                          = [];
pol_deg(pol_deg == 0)                            = [];

%Check for duplicate values in order_lim
if size(order_lim,1) ~= size(unique(order_lim),1)
    error('<order_lim> contains duplicate values.')
end

if issorted(order_lim) ~= 1
    warning('<order_lim> is not sorted in ascending order. Sorting of <order_lim> and <pol_deg> arguments in ascending order will be performed, with respect to <order_lim>.')
    
    %Sort order_lim and pol_deg in ascending order with respect to
    %order_lim
    data_temp                                    = sortrows([order_lim,pol_deg]);
    order_lim                                    = data_temp(:,1);
    pol_deg                                      = data_temp(:,2);
    
end

%Maximum degree of input CS matrix
deg_max                                          = size(CS,1) - 1;

if max(order_lim) > deg_max
    error('<order_lim> value exceeds maximum degree of expansion.')
end

%% Start the algorithm

%Initialize C component of the polynomial degree matrix and populate the
%first section of C_pol
C_pol                                            = pol_deg(1,1)*ones(deg_max + 1);

%Populate C_pol
for i = 1:size(order_lim,1)-1
    
    C_pol(:,order_lim(i,1) + 1:order_lim(i+1,1)) = pol_deg(i,1);
    
end

%Populate the last section of C_pol
C_pol(:,order_lim(end,1) + 1:end)                = pol_deg(end,1);

%Create the polynomial degree matrix in |C\S| format.
pol                                              = f_c_s2cs(C_pol,C_pol);

%Pass clear input data into output variable
input_clear                                      = [order_lim,pol_deg];

end
